//! Hand-written recursive-descent parser producing a rowan green tree.
//!
//! The parser is error-tolerant: it never panics on bad input and always
//! produces a tree whose text is exactly the input, plus diagnostics.
//!
//! The grammar intentionally over-approximates KerML/SysML v2: declarations,
//! statements and expressions share a tolerant "element tail" loop, so many
//! construct families parse through common machinery. The trade-off is
//! tolerance over rejection — some invalid models parse without errors.
//! Conformance is validated against the official SysML-v2-Release corpus
//! (see `sysml corpus` and the corpus regression tests).

use rowan::{Checkpoint, GreenNode, GreenNodeBuilder};

use crate::lexer::Token;
use crate::{Diagnostic, SyntaxKind, SyntaxKind::*, SyntaxNode};

/// Result of parsing: a green tree plus diagnostics.
#[derive(Debug, Clone)]
pub struct Parse {
    green: GreenNode,
    errors: Vec<Diagnostic>,
    dialect: crate::Dialect,
}

impl Parse {
    /// The tree itself, from its root.
    ///
    /// Lossless whatever the input was: its text is the text that was
    /// parsed, byte for byte, trivia and all.
    pub fn syntax(&self) -> SyntaxNode {
        SyntaxNode::new_root(self.green.clone())
    }

    /// Which notation this was read as.
    ///
    /// The two share a syntax tree but not a set of metaclasses: what
    /// SysML writes as a usage with no kind keyword is a
    /// `ReferenceUsage`, and KerML has no such thing.
    pub fn dialect(&self) -> crate::Dialect {
        self.dialect
    }

    /// What the lexer and the parser had to say about the text, in the
    /// order they said it. Parsing never fails, so this is how a caller
    /// finds out that something was wrong.
    pub fn errors(&self) -> &[Diagnostic] {
        &self.errors
    }

    /// Whether they had nothing to say.
    pub fn ok(&self) -> bool {
        self.errors.is_empty()
    }
}

/// Parse a whole source file as SysML (see [`parse_dialect`]).
pub fn parse(text: &str) -> Parse {
    parse_dialect(text, crate::Dialect::SysML)
}

/// Parse a whole `.sysml` / `.kerml` source file in the given dialect.
pub fn parse_dialect(text: &str, dialect: crate::Dialect) -> Parse {
    let (tokens, lex_errors) = crate::lexer::lex_dialect(text, dialect);
    let mut parser = Parser {
        text,
        tokens,
        pos: 0,
        builder: GreenNodeBuilder::new(),
        errors: lex_errors,
        depth: 0,
        gave_up: false,
        plain_target: false,
        carries_payload: false,
    };
    parser.source_file();
    Parse {
        green: parser.builder.finish(),
        errors: parser.errors,
        dialect,
    }
}

/// How much nesting the parser will build structure for.
///
/// Both the recursion and the tree it builds are bounded by this: a
/// thousand open braces would otherwise take the process down with a stack
/// overflow, which is not something a caller can catch, and even a tree
/// built without recursion overflows when it is *dropped*. The corpus
/// nests about a dozen deep, so the limit is only ever reached by input
/// nobody wrote by hand.
const MAX_DEPTH: usize = 512;

struct Parser<'t> {
    text: &'t str,
    tokens: Vec<Token>,
    /// Index into `tokens`, pointing at the next not-yet-consumed token
    /// (trivia included).
    pos: usize,
    builder: GreenNodeBuilder<'static>,
    errors: Vec<Diagnostic>,
    /// How much of [`MAX_DEPTH`] the tree under construction has spent.
    depth: usize,
    /// Set once the limit is reached; from then on the parser reports
    /// nothing further and the rest of the file is flat.
    gave_up: bool,
    /// While reading what a `perform`/`include`/`satisfy` adapts, a `[`
    /// opens the usage's multiplicity rather than an index into the
    /// thing being adapted: `include 'add fuel'[0..*]` includes it zero
    /// or more times.
    plain_target: bool,
    /// While reading a `flow`, `succession flow` or `message`, what
    /// follows `of` is the payload -- even when an `=` comes after it.
    /// KerML's `binding ab of a = b` writes the same shape and means a
    /// connector end, so which statement it is decides which it means.
    carries_payload: bool,
}

impl Parser<'_> {
    // --- cursor primitives -------------------------------------------------

    /// Kind of the n-th upcoming non-trivia token (`EOF` past the end).
    fn nth(&self, n: usize) -> SyntaxKind {
        self.tokens[self.pos..]
            .iter()
            .filter(|t| !t.kind.is_trivia())
            .nth(n)
            .map_or(EOF, |t| t.kind)
    }

    fn current(&self) -> SyntaxKind {
        self.nth(0)
    }

    fn at(&self, kind: SyntaxKind) -> bool {
        self.current() == kind
    }

    /// Byte range of the current non-trivia token (empty range at EOF).
    fn current_range(&self) -> std::ops::Range<usize> {
        self.tokens[self.pos..]
            .iter()
            .find(|t| !t.kind.is_trivia())
            .map_or(self.text.len()..self.text.len(), |t| t.range.clone())
    }

    fn token_into_builder(&mut self) {
        let token = self.tokens[self.pos].clone();
        self.builder
            .token(token.kind.into(), &self.text[token.range]);
        self.pos += 1;
    }

    fn flush_trivia(&mut self) {
        while self
            .tokens
            .get(self.pos)
            .is_some_and(|t| t.kind.is_trivia())
        {
            self.token_into_builder();
        }
    }

    /// Consume the current non-trivia token (attaching preceding trivia to
    /// the currently open node). No-op at EOF.
    fn bump(&mut self) {
        self.flush_trivia();
        if self.pos < self.tokens.len() {
            self.token_into_builder();
        }
    }

    fn eat(&mut self, kind: SyntaxKind) -> bool {
        if self.at(kind) {
            self.bump();
            true
        } else {
            false
        }
    }

    fn expect(&mut self, kind: SyntaxKind) {
        if !self.eat(kind) {
            self.error(format!("expected {kind:?}, found {:?}", self.current()));
        }
    }

    fn error(&mut self, message: impl Into<String>) {
        // Once the depth limit has been reported there is nothing left to
        // say: every enclosing construct is about to find its body missing
        // and would report the same thing again.
        if self.gave_up {
            return;
        }
        let range = self.current_range();
        self.errors.push(Diagnostic::new(&range, message));
    }

    /// Claim one more level of nesting, or give up.
    ///
    /// Giving up means swallowing the rest of the file as loose tokens in
    /// whatever node is open: the text is still reproduced exactly, no
    /// deeper node is built, and every enclosing loop sees EOF and unwinds.
    fn deepen(&mut self) -> bool {
        if self.gave_up {
            return false;
        }
        if self.depth < MAX_DEPTH {
            self.depth += 1;
            return true;
        }
        self.error(format!("nested more than {MAX_DEPTH} deep"));
        self.gave_up = true;
        while self.pos < self.tokens.len() {
            self.token_into_builder();
        }
        false
    }

    // --- node primitives ---------------------------------------------------

    fn start_node(&mut self, kind: SyntaxKind) {
        self.flush_trivia();
        self.builder.start_node(kind.into());
    }

    fn checkpoint(&mut self) -> Checkpoint {
        self.flush_trivia();
        self.builder.checkpoint()
    }

    fn start_node_at(&mut self, checkpoint: Checkpoint, kind: SyntaxKind) {
        self.builder.start_node_at(checkpoint, kind.into());
    }

    fn finish_node(&mut self) {
        self.builder.finish_node();
    }

    /// Wrap the current token in an `ERROR` node and report `message`.
    fn error_and_bump(&mut self, message: impl Into<String>) {
        self.error(message);
        self.start_node(ERROR);
        self.bump();
        self.finish_node();
    }

    // --- token classes -----------------------------------------------------

    fn at_name(&self) -> bool {
        matches!(self.current(), IDENT | UNRESTRICTED_NAME)
    }

    fn nth_is_name(&self, n: usize) -> bool {
        matches!(self.nth(n), IDENT | UNRESTRICTED_NAME)
    }

    /// A bare name that the next token confirms to be a declaration
    /// (`level = 3;`, `x : T;`, enum values `red;`).
    fn at_anonymous_usage(&self) -> bool {
        self.at_name()
            && matches!(
                self.nth(1),
                COLON
                    | COLON_GT
                    | COLON_GT_GT
                    | COLON_COLON_GT
                    | EQ
                    | COLON_EQ
                    | SEMICOLON
                    | L_BRACE
                    | L_BRACKET
                    | DEFAULT_KW
            )
    }

    /// Does `(` open a parameter list (rather than an expression)?
    fn at_param_list(&self) -> bool {
        let k1 = self.nth(1);
        k1.is_modifier_kw()
            || k1.is_def_kind_kw()
            || k1 == L_BRACKET // `([1] myCart, [0..1] products)`
            || (matches!(k1, IDENT | UNRESTRICTED_NAME)
                && matches!(
                    self.nth(2),
                    COLON | COLON_GT | COLON_GT_GT | COLON_COLON_GT | COLON_EQ | DEFAULT_KW
                ))
    }

    fn at_expr_start(&self) -> bool {
        matches!(
            self.current(),
            IDENT
                | UNRESTRICTED_NAME
                | DECIMAL
                | REAL
                | STRING
                | TRUE_KW
                | FALSE_KW
                | NULL_KW
                | L_PAREN
                | MINUS
                | PLUS
                | TILDE
                | NOT_KW
                | IF_KW
                | AT
                | STAR
                | DOLLAR
                | NEW_KW
        )
    }

    // --- grammar: file and members -----------------------------------------

    fn source_file(&mut self) {
        self.builder.start_node(SOURCE_FILE.into());
        while !self.at(EOF) {
            self.member();
        }
        self.flush_trivia();
        self.finish_node();
    }

    /// One member of a namespace/definition body (or of the root namespace).
    fn member(&mut self) {
        let outer = self.depth;
        if self.deepen() {
            self.member_inner();
        }
        self.depth = outer;
    }

    fn member_inner(&mut self) {
        let cp = self.checkpoint();
        // visibility and `#name` user-defined-keyword prefixes, in any order
        loop {
            if self.at(HASH) && self.nth_is_name(1) {
                self.opt_prefix_metadata();
            } else if self.current().is_visibility_kw() {
                self.bump();
            } else {
                break;
            }
        }
        match self.current() {
            PACKAGE_KW | LIBRARY_KW | STANDARD_KW | NAMESPACE_KW => self.package(cp),
            IMPORT_KW => self.import(cp, IMPORT),
            EXPOSE_KW => self.import(cp, EXPOSE),
            ALIAS_KW => self.alias(cp),
            DOC_KW => self.documentation(cp),
            COMMENT_KW => self.comment_elem(cp),
            COMMENT_BODY => {
                // a bare `/* ... */` is a comment element about its owner
                self.start_node_at(cp, COMMENT_ELEM);
                self.bump();
                self.finish_node();
            }
            REP_KW | LANGUAGE_KW => self.rep(cp),
            FILTER_KW => self.filter_member(cp),
            AT | AT_AT => self.metadata_annotation(cp),
            DEPENDENCY_KW => self.lead_stmt(cp, DEPENDENCY),
            CONNECT_KW | BIND_KW | ALLOCATE_KW => self.lead_stmt(cp, CONNECTOR_STMT),
            IF_KW => self.if_member(cp),
            FIRST_KW | THEN_KW | ELSE_KW | WHILE_KW | UNTIL_KW | FOR_KW | LOOP_KW | MERGE_KW
            | DECIDE_KW | FORK_KW | JOIN_KW | SEND_KW | ACCEPT_KW | ASSIGN_KW | TERMINATE_KW
            | DO_KW | ENTRY_KW | EXIT_KW => self.lead_stmt(cp, CONTROL_STMT),
            TRANSITION_KW => self.transition(cp),
            SPECIALIZATION_KW | SUBCLASSIFIER_KW | SUBTYPE_KW | SUBSET_KW | REDEFINITION_KW
            | CONJUGATION_KW | DISJOINING_KW | DISJOINT_KW | INVERTING_KW | INVERSE_KW
            | FEATURING_KW | TYPING_KW => self.lead_stmt(cp, RELATION_STMT),
            // `render asElementTable { ... }` renders by the rendering it
            // names, the way `perform` performs by the action it names;
            // `render rendering r1 : R` declares one instead.
            PERFORM_KW | EXHIBIT_KW | EVENT_KW | INCLUDE_KW | SATISFY_KW | ASSERT_KW
            | ASSUME_KW | REQUIRE_KW | VERIFY_KW | FRAME_KW | RENDER_KW => self.adapter_usage(cp),
            NOT_KW
                if matches!(
                    self.nth(1),
                    PERFORM_KW
                        | EXHIBIT_KW
                        | EVENT_KW
                        | INCLUDE_KW
                        | SATISFY_KW
                        | ASSERT_KW
                        | ASSUME_KW
                        | REQUIRE_KW
                        | VERIFY_KW
                        | FRAME_KW
                ) =>
            {
                self.adapter_usage(cp)
            }
            // `#service def X { ... }` — definition with only user keywords
            DEF_KW => self.definition_or_usage(cp),
            // bare `locale "en_US" /* ... */` comment element
            LOCALE_KW => {
                self.start_node_at(cp, COMMENT_ELEM);
                self.bump();
                self.expect(STRING);
                self.expect(COMMENT_BODY);
                self.finish_node();
            }
            SUBJECT_KW | ACTOR_KW | STAKEHOLDER_KW | OBJECTIVE_KW | RETURN_KW | VARIANT_KW
            | DEFAULT_KW => self.kw_usage(cp),
            // a message carries a payload, and only `definition_or_usage`
            // knows that, so `message m of x = v` must go the same way
            // `abstract message m of x = v` already does
            MESSAGE_KW => self.definition_or_usage(cp),
            k if k.is_modifier_kw() || k.is_def_kind_kw() => self.definition_or_usage(cp),
            // `:>> quantity = isq.L;` — a kind-less usage starting with a
            // feature specialization
            COLON_GT | COLON_GT_GT | COLON_COLON_GT | SPECIALIZES_KW | SUBSETS_KW
            | REDEFINES_KW | REFERENCES_KW | CROSSES_KW | EQ | COLON_EQ => {
                self.start_node_at(cp, USAGE);
                self.element_tail();
                self.finish_node();
            }
            // `level = 3;` / `x : T;` — a kind-less (anonymous) usage
            _ if self.at_anonymous_usage() => {
                self.start_node_at(cp, USAGE);
                self.opt_name();
                self.element_tail();
                self.finish_node();
            }
            _ if self.at_expr_start() => {
                self.start_node_at(cp, EXPR_STMT);
                self.expression();
                if self.at(L_BRACE) {
                    // structured control: `if i < 0 { ... }`
                    self.body();
                }
                self.eat(SEMICOLON);
                self.finish_node();
            }
            _ => self.error_and_bump(format!(
                "expected a member (definition, usage, package, import, ...), found {:?}",
                self.current()
            )),
        }
    }

    /// `standard? library? (package | namespace) Name? Body`
    fn package(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, PACKAGE);
        self.eat(STANDARD_KW);
        self.eat(LIBRARY_KW);
        if !self.eat(PACKAGE_KW) && !self.eat(NAMESPACE_KW) {
            self.error(format!("expected `package`, found {:?}", self.current()));
        }
        self.opt_short_name();
        self.opt_name();
        self.element_tail();
        self.finish_node();
    }

    /// `import all? A::B(::* | ::**)? [filter]* Body`
    fn import(&mut self, cp: Checkpoint, node: SyntaxKind) {
        self.start_node_at(cp, node);
        self.bump();
        self.eat(ALL_KW);
        self.qualified_name(true);
        while self.at(L_BRACKET) {
            self.start_node(FILTER);
            self.bump();
            if !self.at(R_BRACKET) {
                self.expression();
            }
            self.expect(R_BRACKET);
            self.finish_node();
        }
        self.element_tail();
        self.finish_node();
    }

    /// `alias <s>? Name for A::B ;`
    fn alias(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, ALIAS);
        self.bump();
        self.opt_short_name();
        self.opt_name();
        self.expect(FOR_KW);
        self.qualified_name_chain();
        self.element_tail();
        self.finish_node();
    }

    /// `doc Name? (locale "...")? /* ... */`
    fn documentation(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, DOCUMENTATION);
        self.bump();
        self.opt_short_name();
        self.opt_name();
        if self.eat(LOCALE_KW) {
            self.expect(STRING);
        }
        self.expect(COMMENT_BODY);
        self.finish_node();
    }

    /// `comment Name? (about A, B)? (locale "...")? /* ... */`
    fn comment_elem(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, COMMENT_ELEM);
        self.bump();
        self.opt_short_name();
        self.opt_name();
        if self.at(ABOUT_KW) {
            self.about_part();
        }
        if self.eat(LOCALE_KW) {
            self.expect(STRING);
        }
        self.expect(COMMENT_BODY);
        self.finish_node();
    }

    fn about_part(&mut self) {
        self.start_node(ABOUT);
        self.bump();
        self.type_ref();
        while self.eat(COMMA) {
            self.type_ref();
        }
        self.finish_node();
    }

    /// `rep Name? language "lang" /* ... */` (or bare `language "lang" /* */`)
    fn rep(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, REP);
        if self.eat(REP_KW) {
            self.opt_short_name();
            self.opt_name();
            self.expect(LANGUAGE_KW);
        } else {
            self.bump(); // `language`
        }
        self.expect(STRING);
        self.expect(COMMENT_BODY);
        self.finish_node();
    }

    /// `filter expr ;`
    fn filter_member(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, FILTER);
        self.bump();
        self.expression();
        self.expect(SEMICOLON);
        self.finish_node();
    }

    /// `@M about x; | @M { ... } | @@M ...`
    fn metadata_annotation(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, METADATA_ANNOTATION);
        self.bump();
        if self.at_name() {
            self.qualified_name_chain();
        }
        self.element_tail();
        self.finish_node();
    }

    /// `connect a to b;`, `first a then b;`, `specialization s subtype ...`
    fn lead_stmt(&mut self, cp: Checkpoint, node: SyntaxKind) {
        self.start_node_at(cp, node);
        let led = self.current();
        self.bump();
        self.element_tail_from(led);
        self.finish_node();
    }

    /// `transition <shortName>? Name? first a then b;`
    ///
    /// `TransitionUsage = 'transition' ( UsageDeclaration 'first' )? ...`
    /// puts the declaration before `first`, so a transition that reads its
    /// own name as a reference is a transition nothing can name -- the same
    /// trap `connection k connect a to b` sets.
    fn transition(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, CONTROL_STMT);
        self.bump();
        self.opt_short_name();
        self.opt_decl_name();
        self.element_tail();
        self.finish_node();
    }

    /// `perform action a ...`, `assert not constraint ...`, `event x.y;`, ...
    fn adapter_usage(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, USAGE);
        self.eat(NOT_KW); // `not satisfy r1 by p;`
        self.bump();
        self.eat(NOT_KW);
        self.opt_prefix_metadata(); // `assume #goal constraint c;`
        if self.current().is_def_kind_kw() {
            self.def_kind_keywords();
            self.opt_short_name();
            self.opt_decl_name();
            if self.at(L_PAREN) {
                self.param_list();
            }
        } else if self.at_expr_start() {
            self.plain_target = true;
            self.expression();
            self.plain_target = false;
        }
        self.element_tail();
        self.finish_node();
    }

    /// `subject x : T;`, `return x;`, `variant part v;`, `render asTree;`
    fn kw_usage(&mut self, cp: Checkpoint) {
        self.start_node_at(cp, USAGE);
        self.bump();
        // `ActorUsage : PartUsage = 'actor' UsageExtensionKeyword* Usage`,
        // and the same shape for `subject`, `stakeholder`, `objective`,
        // `return` and `variant`: the keyword comes first and the
        // user-defined keywords the model declares come after it, so
        // `actor #safetyEngineer a;` is a member of a requirement.
        self.opt_prefix_metadata();
        self.opt_short_name();
        self.opt_decl_name();
        self.element_tail();
        self.finish_node();
    }

    /// Bump a definition/usage kind keyword sequence (`part`, `use case`,
    /// `assoc struct`, `succession flow`, ...).
    fn def_kind_keywords(&mut self) {
        while self.current().is_def_kind_kw() {
            let k = self.current();
            self.carries_payload |= matches!(k, FLOW_KW | MESSAGE_KW);
            self.bump();
            if k == USE_KW {
                self.eat(CASE_KW);
            }
            if !matches!(k, ASSOC_KW | SUCCESSION_KW) {
                break;
            }
        }
    }

    /// Definitions and usages share modifiers and kind keywords; `def` (or a
    /// KerML classifier kind) decides definition vs usage.
    fn opt_prefix_metadata(&mut self) {
        while self.at(HASH) && self.nth_is_name(1) {
            self.start_node(PREFIX_METADATA);
            self.bump();
            self.qualified_name_chain();
            self.finish_node();
        }
    }

    /// A declaration may lead straight into another one -- `end x feature y
    /// : T` -- so this recurses through `element_tail` without ever passing
    /// through `member`, and needs its own share of the depth budget.
    fn definition_or_usage(&mut self, cp: Checkpoint) {
        let outer = self.depth;
        if self.deepen() {
            self.definition_or_usage_inner(cp);
        }
        self.depth = outer;
    }

    fn definition_or_usage_inner(&mut self, cp: Checkpoint) {
        loop {
            if self.current().is_modifier_kw() {
                self.bump();
            } else if self.at(HASH) && self.nth_is_name(1) {
                self.opt_prefix_metadata();
            } else {
                break;
            }
        }
        // `abstract message messages : M ...` — message declarations after
        // modifiers behave like a usage kind
        self.carries_payload = self.at(MESSAGE_KW);
        self.eat(MESSAGE_KW);
        let is_classifier = matches!(
            self.current(),
            TYPE_KW
                | CLASSIFIER_KW
                | CLASS_KW
                | DATATYPE_KW
                | STRUCT_KW
                | ASSOC_KW
                | BEHAVIOR_KW
                | FUNCTION_KW
                | PREDICATE_KW
                | INTERACTION_KW
                | METACLASS_KW
        );
        // `MetadataUsageDeclaration = ( Identification ( ':' | 'typed'
        // 'by' ) )? OwnedFeatureTyping` -- what follows the keyword is
        // the metadata definition, not a name, unless a name is spelled
        // out in front of it. `metadata Classified { ... }` says what
        // `@Classified { ... }` says.
        let is_metadata = self.at(METADATA_KW);
        self.def_kind_keywords();
        let node = if self.at(DEF_KW) || is_classifier {
            DEFINITION
        } else {
            USAGE
        };
        self.start_node_at(cp, node);
        self.eat(DEF_KW);
        self.eat(ALL_KW); // `struct all Curve` — sufficiency marker
        self.opt_prefix_metadata();
        self.opt_short_name();
        if node == DEFINITION {
            // `def` has been read, and a definition's name is the only
            // thing that belongs after it
            if self.current().is_keyword() {
                self.keyword_as_name();
            } else {
                self.opt_name();
            }
        } else if is_metadata {
            self.opt_typing_name();
        } else {
            // usages: only take a name the next token confirms, so that
            // `flow p1.torque to p2.torque;` keeps `p1.torque` an expression
            self.opt_decl_name();
        }
        if self.at(L_PAREN) {
            self.param_list();
        }
        self.element_tail();
        self.carries_payload = false;
        self.finish_node();
    }

    /// Everything after the lead-in of a declaration or statement, up to and
    /// including the body (`;` or `{ ... }`). Tolerant by design: feature
    /// specializations, multiplicities, values, statement continuation
    /// keywords and expressions may appear in any order.
    fn element_tail(&mut self) {
        self.element_tail_from(EOF);
    }

    /// [`element_tail`], told which keyword the statement's lead-in
    /// consumed. Only a flow keyword matters: a nameless declaration
    /// written after `then` is the action the succession runs into,
    /// where the same shape after `do` is the statement's own body.
    fn element_tail_from(&mut self, led: SyntaxKind) {
        // What the last turn of the loop dispatched on, starting from
        // the lead-in, so `then action { ... }` reads alike whether the
        // `then` opened the statement or came part-way through it.
        let mut previous = led;
        loop {
            let here = self.current();
            let after_flow = matches!(previous, THEN_KW | ELSE_KW | FIRST_KW);
            previous = here;
            match here {
                SEMICOLON => {
                    self.start_node(BODY);
                    self.bump();
                    self.finish_node();
                    return;
                }
                L_BRACE => {
                    self.body();
                    // `if c { ... } else { ... }` carries on past its
                    // first body; nothing else in the language does
                    if self.at(ELSE_KW) {
                        continue;
                    }
                    return;
                }
                EOF | R_BRACE => {
                    self.error("expected `;` or `{`");
                    return;
                }
                COLON | TYPED_KW | DEFINED_KW => self.typing_part(),
                COLON_GT | SPECIALIZES_KW | SUBSETS_KW | CROSSES_KW => {
                    self.relationship_part(SUBSETTING)
                }
                COLON_GT_GT | REDEFINES_KW => self.relationship_part(REDEFINITION),
                COLON_COLON_GT | REFERENCES_KW => self.relationship_part(REFERENCES),
                CHAINS_KW | UNIONS_KW | INTERSECTS_KW | DIFFERENCES_KW | DISJOINT_KW
                | INVERSE_KW | FEATURED_KW | CONJUGATES_KW | CONJUGATE_KW | TILDE => {
                    self.kerml_relation_part()
                }
                L_BRACKET => self.multiplicity(),
                EQ | COLON_EQ | DEFAULT_KW => self.value_part(),
                ABOUT_KW => self.about_part(),
                // `( cause1 ::> causer1, ... )` is a parameter list;
                // `for n in (1, 2, 3)` is an expression
                L_PAREN if self.at_param_list() => self.param_list(),
                L_PAREN => self.expression(),
                // statement continuation keywords and misc glue
                // `flow f of Fuel from a to b` carries a payload; KerML's
                // `binding b of a = c` names a connector end with the same
                // keyword, and the `=` after it is what tells them apart
                // KerML also writes `binding instant[n] of [0..1] a = ...`,
                // where what follows `of` is a multiplicity rather than the
                // payload's type
                OF_KW if self.nth_is_name(1) => self.payload_part(),
                OF_KW | FROM_KW | TO_KW | VIA_KW | THEN_KW | ELSE_KW | FIRST_KW | ACCEPT_KW
                | AT_KW | AFTER_KW | WHEN_KW | UNTIL_KW | WHILE_KW | DO_KW | BY_KW | ALL_KW
                | PARALLEL_KW | ASSIGN_KW | SEND_KW | MERGE_KW | DECIDE_KW | FORK_KW | JOIN_KW
                | TERMINATE_KW | LOOP_KW | FOR_KW | NEW_KW | ORDERED_KW | NONUNIQUE_KW
                | CONNECT_KW | BIND_KW | MESSAGE_KW | ALLOCATE_KW | SUBTYPE_KW | SUBSET_KW
                | REDEFINITION_KW | TYPING_KW | SPECIALIZATION_KW | SUBCLASSIFIER_KW | COMMA
                | QUESTION | QUESTION_QUESTION | FAT_ARROW | LANGUAGE_KW => self.bump(),
                // nested declarations inside statements: `then perform body;`,
                // `then private action whileLoop { ... }`
                PERFORM_KW | EXHIBIT_KW | EVENT_KW | INCLUDE_KW | SATISFY_KW | ASSERT_KW
                | ASSUME_KW | REQUIRE_KW | VERIFY_KW | FRAME_KW => self.bump(),
                k if k.is_visibility_kw() => self.bump(),
                // `connect [1] lugNutPort ::> wheel.lugNutPort to ...` — a
                // named connector end; parse just the name and its
                // reference so `to`/`from` stay with the enclosing statement
                _ if self.at_name() && matches!(self.nth(1), COLON_COLON_GT | REFERENCES_KW) => {
                    self.start_node(USAGE);
                    self.opt_name();
                    self.relationship_part(REFERENCES);
                    self.finish_node();
                }
                // `end [0..1] #M feature x : X;` — a prefix metadata
                // annotation may follow the multiplicity, since
                // `FeaturePrefix` puts the `PrefixMetadataMember`s after
                // the cross feature an `end` may carry. What it
                // annotates is the feature the declaration goes on to
                // name, so it opens the nested declaration rather than
                // being read as part of the one already open.
                HASH if self.nth_is_name(1) => {
                    let nested = self.checkpoint();
                    self.definition_or_usage(nested);
                    return;
                }
                // `end x [1..*] feature y : T redefines z;` — a nested
                // feature declaration ends the enclosing element, and so
                // does the nameless `then action { ... }`, which declares
                // the action the succession runs into
                k if k.is_def_kind_kw()
                    && (self.nth_is_name(1) || (after_flow && self.nth(1) == L_BRACE)) =>
                {
                    let nested = self.checkpoint();
                    self.definition_or_usage(nested);
                    return;
                }
                k if k.is_def_kind_kw() || k.is_modifier_kw() => self.bump(),
                _ if self.at_expr_start() => self.expression(),
                _ => self.error_and_bump(format!(
                    "unexpected token {:?} in declaration",
                    self.current()
                )),
            }
        }
    }

    /// `if c then a else b;` and `if c { ... } else { ... }` are one action
    /// usage -- `IfNode : IfActionUsage = ... 'if' ExpressionParameterMember
    /// ActionBodyParameterMember ( 'else' ActionBodyParameterMember )?` --
    /// while `if c ? t else f` is the conditional expression.
    ///
    /// The `?` is what tells them apart and it only turns up after the
    /// condition, so the node is wrapped once the condition has been read.
    fn if_member(&mut self, cp: Checkpoint) {
        self.bump(); // `if`
        self.expression();
        if self.at(QUESTION) {
            self.bump();
            self.expression();
            if self.eat(ELSE_KW) {
                self.expression();
            }
            self.start_node_at(cp, COND_EXPR);
            self.finish_node();
            self.start_node_at(cp, EXPR_STMT);
            self.eat(SEMICOLON);
            self.finish_node();
            return;
        }
        self.start_node_at(cp, CONTROL_STMT);
        self.element_tail();
        self.finish_node();
    }

    /// `{ member* }`
    fn body(&mut self) {
        self.start_node(BODY);
        self.bump();
        while !matches!(self.current(), R_BRACE | EOF) {
            self.member();
        }
        self.expect(R_BRACE);
        self.finish_node();
    }

    /// A comma continues a type-reference list only when what follows looks
    /// like another plain reference — `in x : X, out y : Y` must leave the
    /// comma to the parameter list.
    ///
    /// A value may follow the last of them: `attribute <H> henry :
    /// PermeanceUnit, InductanceUnit = Wb/A` types the attribute by two
    /// units and then says what it is. Read as a declaration the comma
    /// belonged to, `henry` was typed by the first alone.
    fn continues_ref_list(&self) -> bool {
        self.at(COMMA)
            && (self.nth_is_name(1) || self.nth(1) == TILDE)
            && !matches!(
                self.nth(2),
                COLON | COLON_GT | COLON_GT_GT | COLON_COLON_GT | COLON_EQ | DEFAULT_KW
            )
    }

    /// `: T, U` / `typed by T` / `defined by T`
    fn typing_part(&mut self) {
        self.start_node(TYPING);
        if self.eat(TYPED_KW) || self.eat(DEFINED_KW) {
            self.expect(BY_KW);
        } else {
            self.bump(); // `:`
        }
        self.type_ref();
        while self.continues_ref_list() {
            self.bump();
            self.type_ref();
        }
        self.finish_node();
    }

    /// `(:> | specializes | subsets | crosses | :>> | redefines | ::> | references) T, U`
    fn relationship_part(&mut self, kind: SyntaxKind) {
        self.start_node(kind);
        self.bump();
        self.type_ref();
        while self.continues_ref_list() {
            self.bump();
            self.type_ref();
        }
        self.finish_node();
    }

    /// `of Fuel` / `of fuelCommand : FuelCommand` -- what a flow, a
    /// succession flow or a message carries.
    ///
    /// The payload may be written either way: `PayloadFeature =
    /// Identification PayloadFeatureSpecializationPart ValuePart? | ...
    /// ownedRelationship += OwnedFeatureTyping ...`, so a bare name after
    /// `of` is the payload's *type* unless what follows declares it.
    ///
    /// KerML writes `binding ab of a = b` with the same keyword, where
    /// what follows `of` is a connector end; the `=` after it is what
    /// tells the two apart, so the node is only wrapped once that is known.
    fn payload_part(&mut self) {
        let cp = self.checkpoint();
        self.bump(); // `of`
                     // `of CallGiveItems[1]` is the shorthand with a multiplicity on
                     // it, not a payload named `CallGiveItems`: a declaration must say
                     // what the payload specializes -- or, in a flow, give it a value,
                     // which is `PayloadFeature = Identification ValuePart`.
        let declared = matches!(
            self.nth(1),
            COLON | COLON_GT | COLON_GT_GT | TYPED_KW | DEFINED_KW
        ) || (self.carries_payload
            && matches!(self.nth(1), EQ | COLON_EQ | DEFAULT_KW));
        if declared {
            self.opt_name();
            loop {
                match self.current() {
                    COLON | TYPED_KW | DEFINED_KW => self.typing_part(),
                    COLON_GT | SPECIALIZES_KW | SUBSETS_KW => self.relationship_part(SUBSETTING),
                    COLON_GT_GT | REDEFINES_KW => self.relationship_part(REDEFINITION),
                    L_BRACKET => self.multiplicity(),
                    EQ | COLON_EQ | DEFAULT_KW => self.value_part(),
                    _ => break,
                }
            }
        } else {
            let typing = self.checkpoint();
            self.type_ref();
            if self.at(EQ) && !self.carries_payload {
                return; // a KerML connector end, not a payload
            }
            self.start_node_at(typing, TYPING);
            self.finish_node();
            // `flow f of CallGiveItems[1]` -- the multiplicity counts the
            // payload, not the flow
            if self.at(L_BRACKET) {
                self.multiplicity();
            }
        }
        self.start_node_at(cp, PAYLOAD);
        self.finish_node();
    }

    /// KerML: `chains a.b`, `disjoint from T`, `inverse of f`, `featured by T`,
    /// `unions T`, `conjugates T` and its spelling `~ T`, ...
    fn kerml_relation_part(&mut self) {
        self.start_node(RELATION);
        let lead = self.current();
        self.bump();
        match lead {
            DISJOINT_KW => {
                self.eat(FROM_KW);
            }
            INVERSE_KW => {
                self.eat(OF_KW);
            }
            FEATURED_KW => {
                self.eat(BY_KW);
            }
            _ => {}
        }
        self.type_ref();
        while self.continues_ref_list() {
            self.bump();
            self.type_ref();
        }
        self.finish_node();
    }

    /// `[ ... ]` — the contents are kept as loose tokens without
    /// further structure.
    fn multiplicity(&mut self) {
        self.start_node(MULTIPLICITY);
        self.bump();
        while !matches!(
            self.current(),
            R_BRACKET | SEMICOLON | L_BRACE | R_BRACE | EOF
        ) {
            self.bump();
        }
        self.expect(R_BRACKET);
        self.finish_node();
    }

    /// `= expr` / `:= expr` / `default (= | :=)? expr`
    fn value_part(&mut self) {
        self.start_node(VALUE);
        if self.eat(DEFAULT_KW) {
            let _ = self.eat(EQ) || self.eat(COLON_EQ);
        } else {
            self.bump(); // `=` or `:=`
        }
        if self.at_expr_start() || self.at(L_BRACE) {
            self.expression();
        }
        self.finish_node();
    }

    /// `( param, param )` where each param is a lightweight usage.
    fn param_list(&mut self) {
        self.start_node(PARAM_LIST);
        self.bump();
        while !matches!(self.current(), R_PAREN | EOF) {
            self.param();
            if !self.eat(COMMA) {
                break;
            }
        }
        self.expect(R_PAREN);
        self.finish_node();
    }

    fn param(&mut self) {
        self.start_node(USAGE);
        while self.current().is_modifier_kw() {
            self.bump();
        }
        if self.current().is_def_kind_kw() {
            self.def_kind_keywords();
        }
        if self.at(L_BRACKET) {
            // `[1] myCart` — multiplicity before the parameter name
            self.multiplicity();
        }
        self.opt_short_name();
        self.opt_name();
        loop {
            match self.current() {
                COLON | TYPED_KW | DEFINED_KW => self.typing_part(),
                COLON_GT | SPECIALIZES_KW | SUBSETS_KW => self.relationship_part(SUBSETTING),
                COLON_GT_GT | REDEFINES_KW => self.relationship_part(REDEFINITION),
                COLON_COLON_GT | REFERENCES_KW => self.relationship_part(REFERENCES),
                L_BRACKET => self.multiplicity(),
                EQ | COLON_EQ | DEFAULT_KW => self.value_part(),
                ORDERED_KW | NONUNIQUE_KW => self.bump(),
                _ => break,
            }
        }
        self.finish_node();
    }

    // --- names -------------------------------------------------------------

    fn opt_name(&mut self) {
        if self.at_name() {
            self.start_node(NAME);
            self.bump();
            self.finish_node();
        }
    }

    /// A reserved word written where a definition's name belongs.
    ///
    /// Both notations reserve their keywords, and a name that collides
    /// with one is written in single quotes: `part def 'frame';`. Bare,
    /// the keyword used to fall through to [`Self::element_tail`], which
    /// sweeps up loose keywords -- so the definition came out with no
    /// name at all, and nothing was said, because nothing had asked for
    /// one.
    ///
    /// Only after `def` (or a KerML classifier keyword), where a name is
    /// the one thing that belongs. A usage's name is not so certain:
    /// `return part : Engine;` is a return parameter that is a part, and
    /// `succession first [0..1] a then b;` opens the succession's own
    /// clause -- in both the keyword is doing its own job in the very
    /// position a name would take, and the official corpus writes both.
    ///
    /// The word is taken as the name it was written as, so the rest of
    /// the declaration still reads as one, and the message says how to
    /// spell it.
    fn keyword_as_name(&mut self) {
        let word = &self.text[self.current_range()];
        let message = format!("`{word}` is reserved; write `'{word}'` to use it as a name");
        self.error(message);
        self.start_node(NAME);
        self.bump();
        self.finish_node();
    }

    /// A name is only consumed when the following token confirms this is a
    /// declaration (used for `return x;` vs `return x * 2;`).
    /// The name of a metadata usage, which only a `:` or a `typed by`
    /// after it makes one. Without one the name is the metadata
    /// definition the usage is typed by, and the typing that says so is
    /// built around it here -- `metadata Classified { ... }` reads as
    /// `metadata : Classified { ... }`.
    fn opt_typing_name(&mut self) {
        if !self.at_name() {
            return;
        }
        if matches!(self.nth(1), COLON | TYPED_KW) {
            self.opt_name();
            return;
        }
        self.start_node(TYPING);
        self.type_ref();
        self.finish_node();
    }

    fn opt_decl_name(&mut self) {
        if self.at_name()
            && matches!(
                self.nth(1),
                COLON
                    | COLON_GT
                    | COLON_GT_GT
                    | COLON_COLON_GT
                    | L_BRACKET
                    | L_PAREN
                    | EQ
                    | COLON_EQ
                    | SEMICOLON
                    | L_BRACE
                    | DEFAULT_KW
                    | ORDERED_KW
                    | NONUNIQUE_KW
                    | OF_KW
                    | FROM_KW
                    | TO_KW
                    | VIA_KW
                    | SPECIALIZES_KW
                    | SUBSETS_KW
                    | REDEFINES_KW
                    | REFERENCES_KW
                    | CROSSES_KW
                    | TYPED_KW
                    | DEFINED_KW
                    // the KerML relations, which follow a declared name
                    // exactly as `chains` does -- leaving one out reads
                    // the name as a reference and the declaration loses
                    // its name entirely
                    | CHAINS_KW
                    | UNIONS_KW
                    | INTERSECTS_KW
                    | DIFFERENCES_KW
                    | DISJOINT_KW
                    | INVERSE_KW
                    | FEATURED_KW
                    | CONJUGATES_KW
                    | CONJUGATE_KW
                    // `ConjugationPart = ( 'conjugates' | '~' ) ...`:
                    // `feature g ~ B::f;` conjugates the same way, and
                    // read as an expression it declared no `g` at all
                    | TILDE
                    // `connection k connect a to b;` -- the same trap: a
                    // named connector whose name is read as a reference
                    // is a connector nothing can name
                    | CONNECT_KW
                    | BIND_KW
                    | ALLOCATE_KW
                    // `succession s first a then b;` and `transition t
                    // first a then b;` declare themselves before `first`
                    | FIRST_KW
            )
        {
            self.opt_name();
        }
    }

    /// `<shortName>`
    fn opt_short_name(&mut self) {
        if self.at(LT) {
            self.start_node(SHORT_NAME);
            self.bump();
            while !matches!(self.current(), GT | SEMICOLON | L_BRACE | R_BRACE | EOF) {
                self.bump();
            }
            self.expect(GT);
            self.finish_node();
        }
    }

    /// A (possibly conjugated `~`) reference to a type or feature chain.
    fn type_ref(&mut self) {
        self.start_node(TYPE_REF);
        self.eat(TILDE);
        if self.at_name() || self.at(DOLLAR) {
            self.qualified_name_chain();
        } else {
            self.error(format!("expected a name, found {:?}", self.current()));
        }
        self.finish_node();
    }

    /// `A::B::C`, optionally ending in `::*` / `::**` (imports).
    ///
    /// `QualifiedName = ('$' '::')? (NAME '::')* NAME`: a leading `$` is the
    /// global root, and an import may start there like anything else.
    fn qualified_name(&mut self, allow_wildcards: bool) {
        self.start_node(QUALIFIED_NAME);
        if self.at_name()
            || self.at(DOLLAR)
            || (allow_wildcards && matches!(self.current(), STAR | STAR_STAR))
        {
            self.bump();
        } else {
            self.error(format!("expected a name, found {:?}", self.current()));
        }
        while self.at(COLON_COLON) {
            self.bump();
            match self.current() {
                IDENT | UNRESTRICTED_NAME => self.bump(),
                STAR | STAR_STAR if allow_wildcards => self.bump(),
                _ => {
                    self.error(format!(
                        "expected a name after `::`, found {:?}",
                        self.current()
                    ));
                    break;
                }
            }
        }
        self.finish_node();
    }

    /// `A::B.c.d` — qualified name that may continue as a feature chain
    /// (`$::A::B` roots at the global namespace).
    fn qualified_name_chain(&mut self) {
        self.start_node(QUALIFIED_NAME);
        if self.at_name() || self.at(DOLLAR) {
            self.bump();
        } else {
            self.error(format!("expected a name, found {:?}", self.current()));
        }
        while matches!(self.current(), COLON_COLON | DOT) && self.nth_is_name(1) {
            self.bump();
            self.bump();
        }
        self.finish_node();
    }

    // --- expressions (Pratt) ----------------------------------------------

    fn expression(&mut self) {
        self.expr_bp(0);
    }

    fn expr_bp(&mut self, min_bp: u8) {
        let outer = self.depth;
        if self.deepen() {
            self.expr_bp_inner(min_bp);
        }
        self.depth = outer;
    }

    fn expr_bp_inner(&mut self, min_bp: u8) {
        let cp = self.checkpoint();
        match self.current() {
            NOT_KW | MINUS | PLUS | TILDE | ALL_KW => {
                self.start_node(UNARY_EXPR);
                self.bump();
                self.expr_bp(13);
                self.finish_node();
            }
            AT | AT_AT => {
                self.start_node(UNARY_EXPR);
                self.bump();
                if self.at_name() {
                    self.qualified_name_chain();
                }
                self.finish_node();
            }
            // `(as Safety)` — classification with elided subject
            AS_KW | ISTYPE_KW | HASTYPE_KW | META_KW => {
                self.start_node(UNARY_EXPR);
                self.bump();
                self.type_ref();
                self.finish_node();
            }
            // `new Translation(args)` — constructor expression
            NEW_KW => {
                self.start_node(UNARY_EXPR);
                self.bump();
                if self.at_name() {
                    self.qualified_name_chain();
                } else {
                    self.error("expected a type name after `new`");
                }
                self.finish_node();
            }
            IF_KW => {
                // `if c ? t else f` (a lone `if c` is left open for
                // transition guards: `accept x if c then s`)
                self.start_node(COND_EXPR);
                self.bump();
                self.expr_bp(0);
                if self.eat(QUESTION) {
                    self.expr_bp(0);
                    if self.eat(ELSE_KW) {
                        self.expr_bp(0);
                    }
                }
                self.finish_node();
            }
            DECIMAL | REAL | STRING | TRUE_KW | FALSE_KW | NULL_KW | STAR => {
                self.start_node(LITERAL);
                self.bump();
                self.finish_node();
            }
            // `$` is the global root, so `$::A::b` is a reference like any
            // other and reads its `::` segments the same way
            IDENT | UNRESTRICTED_NAME | DOLLAR => {
                self.start_node(NAME_REF);
                self.bump();
                while self.at(COLON_COLON) && self.nth_is_name(1) {
                    self.bump();
                    self.bump();
                }
                self.finish_node();
            }
            L_PAREN => {
                self.start_node(PAREN_EXPR);
                self.bump();
                if !self.at(R_PAREN) {
                    self.expr_bp(0);
                    while self.eat(COMMA) {
                        if self.at(R_PAREN) {
                            break;
                        }
                        self.expr_bp(0);
                    }
                }
                self.expect(R_PAREN);
                self.finish_node();
            }
            // `{ true }` — an expression body (e.g. parameter defaults)
            L_BRACE => self.body_expr(),
            _ => {
                self.error(format!(
                    "expected an expression, found {:?}",
                    self.current()
                ));
                return;
            }
        }
        // Each postfix and each binary operator wraps everything read so
        // far in a new node, so `a.a.a...` and `1 + 1 + 1 ...` grow the tree
        // one level per operator without ever recursing. Dropping such a
        // tree is what overflows, so the loop spends the budget too.
        while self.deepen() {
            match self.current() {
                DOT | DOT_QUESTION if self.nth_is_name(1) => {
                    self.start_node_at(cp, PATH_EXPR);
                    self.bump();
                    self.bump();
                    self.finish_node();
                    continue;
                }
                // `MetadataAccessExpression = ElementReferenceMember
                // '.' 'metadata'` — what a metadata access is written
                // as, and `metadata` is a keyword rather than a name
                DOT if self.nth(1) == METADATA_KW => {
                    self.start_node_at(cp, METADATA_ACCESS_EXPR);
                    self.bump();
                    self.bump();
                    self.finish_node();
                    continue;
                }
                // `list.?{in p; cond}` — filtering with a body expression
                DOT | DOT_QUESTION if self.nth(1) == L_BRACE => {
                    self.start_node_at(cp, PATH_EXPR);
                    self.bump();
                    self.body_expr();
                    self.finish_node();
                    continue;
                }
                ARROW => {
                    self.start_node_at(cp, ARROW_EXPR);
                    self.bump();
                    if self.at_name() {
                        self.bump();
                    } else {
                        self.error("expected a function name after `->`");
                    }
                    match self.current() {
                        L_PAREN => self.arg_list(),
                        L_BRACE => self.body_expr(),
                        UNRESTRICTED_NAME | STRING => self.bump(),
                        _ => {}
                    }
                    self.finish_node();
                    continue;
                }
                L_PAREN => {
                    self.start_node_at(cp, CALL_EXPR);
                    self.arg_list();
                    self.finish_node();
                    continue;
                }
                L_BRACKET if !self.plain_target => {
                    self.start_node_at(cp, INDEX_EXPR);
                    self.bump();
                    if !self.at(R_BRACKET) {
                        self.expr_bp(0);
                        while self.eat(COMMA) {
                            self.expr_bp(0);
                        }
                    }
                    self.expect(R_BRACKET);
                    self.finish_node();
                    continue;
                }
                HASH if self.nth(1) == L_PAREN => {
                    self.start_node_at(cp, INDEX_EXPR);
                    self.bump();
                    self.arg_list();
                    self.finish_node();
                    continue;
                }
                _ => {}
            }
            let Some((lbp, type_rhs)) = binary_bp(self.current()) else {
                break;
            };
            if lbp < min_bp {
                break;
            }
            self.start_node_at(cp, BINARY_EXPR);
            self.bump();
            if type_rhs {
                if self.at_name() || self.at(TILDE) {
                    self.type_ref();
                } else {
                    self.expr_bp(13);
                }
            } else {
                self.expr_bp(lbp + 1);
            }
            self.finish_node();
        }
    }

    /// `( expr, name = expr, ... )`
    fn arg_list(&mut self) {
        self.start_node(ARG_LIST);
        self.bump();
        while !matches!(self.current(), R_PAREN | EOF) {
            if self.at_name() && self.nth(1) == EQ {
                self.start_node(NAME_REF);
                self.bump();
                self.finish_node();
                self.bump();
                self.expr_bp(0);
            } else if self.eat(REDEFINES_KW) {
                self.opt_name();
                if self.eat(EQ) {
                    self.expr_bp(0);
                }
            } else if self.at_expr_start() {
                self.expr_bp(0);
            } else {
                self.error_and_bump("expected an argument");
            }
            if !self.eat(COMMA) {
                break;
            }
        }
        self.expect(R_PAREN);
        self.finish_node();
    }

    /// `{ ... }` used as an expression body (after `->collect` etc.)
    fn body_expr(&mut self) {
        self.start_node(BODY_EXPR);
        self.bump();
        while !matches!(self.current(), R_BRACE | EOF) {
            self.member();
        }
        self.expect(R_BRACE);
        self.finish_node();
    }
}

/// Left binding power of a binary operator; `true` marks operators whose
/// right operand is a type reference (`istype`, `as`, ...).
fn binary_bp(kind: SyntaxKind) -> Option<(u8, bool)> {
    let bp = match kind {
        QUESTION_QUESTION => (1, false),
        IMPLIES_KW => (2, false),
        OR_KW | PIPE => (3, false),
        XOR_KW => (4, false),
        AND_KW | AMP => (5, false),
        EQ_EQ | NOT_EQ | EQ_EQ_EQ | NOT_EQ_EQ => (6, false),
        ISTYPE_KW | HASTYPE_KW | AS_KW | META_KW => (7, true),
        LT | GT | LT_EQ | GT_EQ => (8, false),
        DOT_DOT => (9, false),
        PLUS | MINUS => (10, false),
        STAR | SLASH | PERCENT => (11, false),
        STAR_STAR | CARET => (12, false),
        _ => return None,
    };
    Some(bp)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn check_ok(text: &str) -> Parse {
        let parse = parse(text);
        assert_eq!(parse.errors(), &[], "unexpected errors for:\n{text}");
        assert_eq!(parse.syntax().text().to_string(), text, "lossless violated");
        parse
    }

    #[test]
    fn minimal_definition() {
        let parse = check_ok("part def Vehicle;");
        let tree = format!("{:#?}", parse.syntax());
        let expected = r#"SOURCE_FILE@0..17
  DEFINITION@0..17
    PART_KW@0..4 "part"
    WHITESPACE@4..5 " "
    DEF_KW@5..8 "def"
    WHITESPACE@8..9 " "
    NAME@9..16
      IDENT@9..16 "Vehicle"
    BODY@16..17
      SEMICOLON@16..17 ";"
"#;
        assert_eq!(tree, expected);
    }

    #[test]
    fn package_with_members() {
        check_ok(
            "package VehicleModel {\n    import ScalarValues::*;\n    part def Vehicle {\n        attribute mass : Real = 1200.0;\n        part wheels : Wheel[4];\n    }\n}\n",
        );
    }

    #[test]
    fn specialization_and_redefinition() {
        check_ok("abstract part def PowerSource;");
        check_ok("part def Engine :> PowerSource, Producer { port fuelIn : FuelPort; }");
        check_ok("part e :>> engine { attribute :>> mass = 90.0; }");
        check_ok("part def Engine specializes PowerSource;");
        check_ok("ref part best subsets vehicles;");
    }

    #[test]
    fn docs_comments_aliases() {
        check_ok("package P { doc /* documented */ alias V for Q::Vehicle; }");
        check_ok("comment about Vehicle, Engine /* both of them */");
        check_ok("package P { // note\n //* block note */ part def X; }");
        check_ok("package P { /* bare comment */ }");
    }

    #[test]
    fn imports() {
        check_ok("import A;");
        check_ok("import A::B::C;");
        check_ok("import all Q::*;");
        check_ok("import Q::**;");
        check_ok("private import Q::'quoted name';");
        check_ok("import Q::* [@Safety];");
    }

    /// `QualifiedName = ('$' '::')? (NAME '::')* NAME`: the global root is
    /// a qualified name's first segment wherever a qualified name may go.
    #[test]
    fn the_global_root_starts_a_name_in_every_position() {
        check_ok("import $::Objects::*;");
        check_ok("import all $::A::B;");
        check_ok("alias O for $::Objects::Object;");
        check_ok_kerml("class E :> $::Objects::Object;");
        check_ok("attribute a = $::A::b;");
        check_ok("attribute b = $::A::b + 1;");
        // and it is a reference, not a literal
        let parse = check_ok("attribute a = $::A::b;");
        assert!(format!("{:#?}", parse.syntax()).contains("NAME_REF"));
    }

    /// A statement that reads its own name as a reference is a statement
    /// nothing can name -- and a reference to something that is not there.
    #[test]
    fn a_succession_and_a_transition_declare_their_names() {
        for text in [
            "succession s first a then b;",
            "transition t first a then b;",
            "transition <t1> t first a then b;",
        ] {
            let parse = check_ok(text);
            let tree = format!("{:#?}", parse.syntax());
            assert!(
                tree.contains("NAME@"),
                "{text} has no declared name:\n{tree}"
            );
        }
        // a nameless one still reads `a` as where it starts
        let tree = format!("{:#?}", check_ok("succession first a then b;").syntax());
        assert!(!tree.contains("NAME@"), "{tree}");
    }

    /// Every error-recovery arm keeps the full text and reports something.
    #[test]
    fn error_paths_recover() {
        for text in [
            "standard;",                 // `standard` without `package`
            "part x",                    // missing body at EOF
            "part x % ;",                // junk token in a declaration
            "part x : ;",                // missing type name
            "import *;",                 // wildcard head
            "import A::%;",              // junk after `::`
            "alias a for ;",             // missing alias target
            "attribute a = new ;",       // `new` without type
            "attribute b = (1, 2, );",   // trailing comma sequence
            "attribute c = x-> ;",       // arrow without function name
            "attribute d = a[1, 2];",    // multi-index
            "attribute e = x istype 5;", // classification with non-name
            "attribute f = f(%%);",      // broken argument
            "attribute g = f(redefines x = 1);",
            "attribute h = f(y = 2);",
            "calc sum(in x);", // usage with parameter list
            "action def A (part p : P, q :> r, s :>> t, u ::> v, w[2], k = 1 ordered);",
            "doc",                     // missing comment body
            "part p { @ }",            // annotation without name
            "#;",                      // stray hash
            "part x =",                // value at EOF
            "part y [1",               // unterminated multiplicity
            "part def <s",             // unterminated short name
            "perform action f(in x);", // adapter with parameter list
            "import ;",                // import without a target
            "attribute i = a[];",      // empty index
        ] {
            let parse = parse(text);
            assert_eq!(parse.syntax().text().to_string(), text, "lossless: {text}");
        }
    }

    /// Nesting past the limit used to take the process down: the recursion
    /// overflowed the stack while parsing, and where the tree was built by
    /// a loop instead it overflowed again when rowan dropped it.
    #[test]
    fn nesting_past_the_limit_is_reported_once_and_left_flat() {
        for text in [
            format!("part def A {{{}", "part b {".repeat(20_000)),
            format!("attribute x = {};", "(".repeat(50_000)),
            format!("attribute x = a{};", ".a".repeat(20_000)),
            format!("attribute x = 1{};", " + 1".repeat(20_000)),
            (0..20_000).fold(String::new(), |text, n| text + &format!("part a{n} ")) + ";",
            format!("attribute x = f{};", "(1)".repeat(20_000)),
        ] {
            let parse = parse(&text);
            assert_eq!(parse.syntax().text().to_string(), text, "lossless");
            let deep: Vec<_> = parse
                .errors()
                .iter()
                .filter(|e| e.message.contains("nested more than"))
                .collect();
            assert_eq!(deep.len(), 1, "for {}...", &text[..20]);
            // and nothing is said after it
            assert_eq!(parse.errors().last(), deep.first().copied());
            // the tree is shallow enough to walk -- and to drop
            let deepest = parse
                .syntax()
                .descendants()
                .map(|node| node.ancestors().count())
                .max()
                .unwrap();
            assert!(deepest <= MAX_DEPTH + 8, "{deepest} levels");
        }
    }

    /// A definition named after a reserved word used to lose its name:
    /// `element_tail` swept the keyword up and nothing said so, because
    /// nothing had asked for a name. The word is kept -- as the name it
    /// was written as, so an editor can still find and rename it -- and
    /// the message says how to spell it.
    #[test]
    fn a_reserved_word_where_a_definition_is_named() {
        for (text, word) in [
            ("part def frame;", "frame"),
            ("part def action;", "action"),
            // a word the modifier loop would otherwise have taken
            ("part def end;", "end"),
        ] {
            let parse = parse(text);
            assert_eq!(parse.syntax().text().to_string(), text, "lossless: {text}");
            let said: Vec<&str> = parse.errors().iter().map(|e| e.message.as_str()).collect();
            assert_eq!(
                said,
                [format!(
                    "`{word}` is reserved; write `'{word}'` to use it as a name"
                )],
                "for {text}"
            );
            // kept, so the name is still there to resolve and to rename
            let tree = format!("{:#?}", parse.syntax());
            assert!(tree.contains("NAME@"), "no name node for {text}:\n{tree}");
        }
    }

    /// And the same words where they are doing their own job in the very
    /// position a name would take: `part` here is the parameter's kind,
    /// and `first` opens the succession's own clause. Both are written
    /// in the official corpus, which is why the check above is only
    /// where a definition is named and not wherever a name may stand.
    #[test]
    fn a_keyword_in_a_name_s_place_that_is_not_a_name() {
        check_ok("calc def C { in part : Engine; return part : Engine; }");
        check_ok("action def A { succession first [0..1] a then [1] b; }");
        // and a name that only needed quoting is taken as written
        check_ok("part def 'frame';");
    }

    #[test]
    fn error_recovery_keeps_text_and_reports() {
        let text = "part def { \n junk %% tokens \n part def Ok;";
        let parse = parse(text);
        assert!(!parse.errors().is_empty());
        assert_eq!(parse.syntax().text().to_string(), text);
    }

    #[test]
    fn directions_on_usages() {
        check_ok("port def P { in item x : X; out item y : Y; inout ref part z; }");
    }

    #[test]
    fn expressions() {
        check_ok("attribute a = 1 + 2 * 3;");
        check_ok("attribute b = (x >= 0) and not (y < z);");
        check_ok("attribute c = if x > 0 ? x else -x;");
        check_ok("attribute d = vals->select {in v; v > 0}->size();");
        check_ok("attribute e = 10 [SI::kg];");
        check_ok("attribute f = seq#(1);");
        check_ok("attribute g = a.b.c ** 2;");
        check_ok("attribute h = x istype Vehicle;");
        check_ok("constraint c { mass <= maxMass }");
    }

    #[test]
    fn calc_and_constraint_defs() {
        check_ok("calc def Force { in mass : Real; in acc : Real; mass * acc }");
        check_ok("calc def Sum(a : Real, b : Real) : Real { a + b }");
        check_ok("constraint def MaxMass { actual <= allowed }");
        check_ok(
            "requirement def R { subject v : Vehicle; require constraint { v.mass < 100.0 } }",
        );
    }

    #[test]
    fn states_and_actions() {
        check_ok("state def S { entry; then idle; state idle; transition first idle accept sig then busy; state busy; }");
        check_ok("action def A (in x : X, out y : Y) { first start; then s1; action s1; send x to y via p; }");
        check_ok("part p { perform action a { assign x := x + 1; } exhibit state s parallel { } }");
    }

    /// What a message carries is the same thing whether or not a modifier
    /// came first; only the route through the parser differed.
    #[test]
    fn a_message_carries_a_payload_however_it_is_written() {
        let from_the_keyword = |text: &str| {
            let tree = format!("{:#?}", check_ok(text).syntax());
            let kinds: Vec<String> = tree
                .lines()
                .map(|line| line.trim().split('@').next().unwrap().to_string())
                .collect();
            let at = kinds.iter().position(|kind| kind == "MESSAGE_KW").unwrap();
            kinds[at..].to_vec()
        };
        assert_eq!(
            from_the_keyword("message m of x = v from a to b;"),
            from_the_keyword("abstract message m of x = v from a to b;")
        );
        check_ok("message messages : M;");
    }

    #[test]
    fn connections_and_flows() {
        check_ok("part p { connect w.hub to axle; bind a = b; flow of Fuel from tank.fuelOut to eng.fuelIn; }");
        check_ok("part p { message m of Sig from a to b; allocate x to y; }");
        check_ok("interface def I { end p1 : P; end p2 : ~P; }");
    }

    fn check_ok_kerml(text: &str) -> Parse {
        let parse = parse_dialect(text, crate::Dialect::KerML);
        assert_eq!(parse.errors(), &[], "unexpected errors for:\n{text}");
        assert_eq!(parse.syntax().text().to_string(), text, "lossless violated");
        parse
    }

    #[test]
    fn kerml_declarations() {
        check_ok_kerml("classifier Vehicle :> Thing { feature mass : Real; }");
        check_ok_kerml("datatype Real :> ScalarValue;");
        check_ok_kerml("function Plus { in a : Real; in b : Real; return : Real; }");
        check_ok_kerml("assoc struct Owns { end owner : Person; end owned : Thing; }");
        check_ok_kerml("feature f : T chains a.b;");
        check_ok_kerml("classifier A disjoint from B unions C, D;");
        check_ok_kerml("specialization s subtype A specializes B;");
        // SysML-only keywords are plain names in KerML
        check_ok_kerml("feature frame : Frame { feature entry : E; }");
    }

    #[test]
    fn metadata_and_extensions() {
        check_ok("@Safety;");
        check_ok("metadata def Safety { attribute level : Integer; }");
        check_ok("part p { @Safety { level = 3; } }");
        check_ok("#command action doIt;");
        check_ok("filter @Safety;");
    }

    #[test]
    fn short_names_and_quantities() {
        check_ok("attribute def <kg> Kilogram :> MassUnit;");
        check_ok("attribute <A> ampere : Ampere;");
    }

    #[test]
    fn requirements_and_cases() {
        check_ok("requirement r { subject s : System; assume constraint { s.ok } }");
        check_ok("use case def Drive { objective { doc /* drive */ } actor driver : Person; }");
        check_ok("analysis def Fuel { subject v : Vehicle; return fuelEconomy : Real; }");
        check_ok("verification def V { objective verifyMass { verify massReq; } }");
        check_ok("satisfy requirement massReq by vehicle;");
    }
}
