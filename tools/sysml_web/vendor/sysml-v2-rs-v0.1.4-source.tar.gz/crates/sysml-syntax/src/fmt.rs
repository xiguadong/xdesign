//! Canonical formatter for the KerML / SysML v2 textual notation.
//!
//! Token-stream based, driven by the lossless CST: indentation follows
//! brace depth, one member per line, single blank lines are preserved,
//! comments keep their own-line/trailing position, and spacing is decided
//! from token kinds plus the parent node (so `a < b` gets spaces while
//! `<shortName>` does not). A block comment's interior is brought under
//! the column its `/*` ends up in, since it is one token's text and
//! nothing else here reaches it.
//!
//! Guarantees, regression-tested against the whole official corpus:
//! formatting never changes the non-trivia token stream except for the
//! indentation of a comment's own interior, which is not part of what
//! the comment says -- `Model` reads the body with that margin taken
//! off -- and is idempotent.

use crate::{parse_dialect, shared_indent, Dialect, SyntaxKind, SyntaxKind::*, SyntaxToken};

const INDENT: &str = "    ";

/// How wide a line may be before the formatter looks for somewhere to
/// break it, where nobody says otherwise.
///
/// Nothing in the notation makes a line too long -- a newline is
/// whitespace wherever it falls -- so this is about reading. A hundred
/// columns is what fits beside a diagram preview on a laptop, which is
/// where these files are read.
const WIDTH: usize = 100;

/// What the formatter is free to decide, for a caller with an opinion
/// about it.
///
/// Everything else it does is the notation's: four spaces, one member to
/// a line, a `doc` on its own. Where a line that will not fit gives way
/// is the one thing a reader can reasonably want a say in, so it is the
/// one thing here.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Layout {
    /// Columns a line may reach before it is broken, counting a
    /// character an em across as two. Zero leaves every line as long as
    /// it comes, which is what the formatter did before it could break
    /// one at all.
    pub width: usize,
}

impl Default for Layout {
    fn default() -> Layout {
        Layout { width: WIDTH }
    }
}

/// How wide `text` is on screen. A character an em across takes two
/// columns, which is what makes a line of Japanese twice as long as its
/// characters.
fn columns(text: &str) -> usize {
    unicode_width::UnicodeWidthStr::width(text)
}

/// Somewhere a line may be broken: the space before a token, and how
/// readily it gives way.
struct Joint {
    /// Offset of that space in the output.
    at: usize,
    /// Lower gives way first, so that what lands on either side of a
    /// break is a thought rather than a fragment: a whole `else` arm
    /// before either operand of a sum.
    rank: u8,
    /// Whether the author broke the line here. Their break is kept
    /// whether or not the line would have fitted: where a formula is
    /// split says how it is meant to be read, and that is not something
    /// to work out again from the width.
    kept: bool,
}

/// How readily the space before `next` gives way, if at all.
fn joint_rank(prev: &SyntaxToken, next: &SyntaxToken) -> Option<u8> {
    // after these rather than before them: what follows a comma or an
    // `=` is the next thing, and what follows an operator is its operand
    match prev.kind() {
        COMMA => return Some(4),
        EQ | COLON_EQ => return Some(1),
        _ => {}
    }
    Some(match next.kind() {
        ELSE_KW => 0,
        IMPLIES_KW => 2,
        OR_KW | XOR_KW | PIPE => 3,
        AND_KW | AMP => 3,
        EQ_EQ | EQ_EQ_EQ | NOT_EQ | NOT_EQ_EQ | LT | LT_EQ | GT | GT_EQ => 5,
        PLUS | MINUS => 6,
        STAR | SLASH | PERCENT | STAR_STAR | CARET => 7,
        QUESTION | QUESTION_QUESTION => 8,
        _ => return None,
    })
}

/// Format a whole source file.
pub fn format(text: &str, dialect: Dialect) -> String {
    format_with(text, dialect, Layout::default())
}

/// The same, laid out as `layout` asks.
pub fn format_with(text: &str, dialect: Dialect, layout: Layout) -> String {
    format_parsed_with(&parse_dialect(text, dialect), layout)
}

/// Format a file that has already been parsed.
///
/// The tree is all the formatter reads, so a caller that has one -- the
/// command line, which parses to find out whether the file is worth
/// rewriting at all -- need not have it parsed a second time.
pub fn format_parsed(parse: &crate::Parse) -> String {
    format_parsed_with(parse, Layout::default())
}

/// The same, laid out as `layout` asks.
pub fn format_parsed_with(parse: &crate::Parse, layout: Layout) -> String {
    let all_tokens: Vec<SyntaxToken> = parse
        .syntax()
        .descendants_with_tokens()
        .filter_map(|e| e.into_token())
        .collect();
    // A leading byte order mark is trivia to the grammar but tells the next
    // reader how the file is encoded, so formatting keeps it where it is
    // rather than quietly changing what the file claims to be.
    let marked = all_tokens
        .first()
        .is_some_and(|token| token.text().starts_with('\u{feff}'));
    let formatted = Formatter {
        layout,
        out: String::new(),
        depth: 0,
        line_empty: true,
        pending_newlines: 0,
        prev: None,
        line_start: 0,
        line_indent: 0,
        joints: Vec::new(),
        line_breakable: true,
    }
    .run(&all_tokens);
    if marked {
        format!("\u{feff}{formatted}")
    } else {
        formatted
    }
}

/// Format using the dialect implied by a file name.
pub fn format_file(name: &str, text: &str) -> String {
    format(text, Dialect::from_path(name))
}

struct Formatter {
    layout: Layout,
    out: String,
    depth: usize,
    /// nothing emitted on the current line yet
    line_empty: bool,
    /// newlines to emit before the next token
    pending_newlines: usize,
    prev: Option<SyntaxToken>,
    /// where the line being written starts, and how wide its indent is
    line_start: usize,
    line_indent: usize,
    /// where that line could be broken, in the order the spaces appear
    joints: Vec<Joint>,
    /// A line holding a comment that spans lines is already more than
    /// one line, and the offsets a break is spliced in at do not survive
    /// that, so it is left alone.
    line_breakable: bool,
}

impl Formatter {
    fn run(mut self, all_tokens: &[SyntaxToken]) -> String {
        let visible: Vec<&SyntaxToken> = all_tokens
            .iter()
            .filter(|t| !t.kind().is_trivia() || is_note(t.kind()))
            .collect();

        let mut skip_next = false;
        for (index, token) in visible.iter().enumerate() {
            if skip_next {
                skip_next = false;
                continue;
            }
            let kind = token.kind();
            let gap = self.original_gap_lines(token);

            if is_note(kind) {
                if gap == 0 && !self.line_empty && self.prev.is_some() {
                    // trailing note stays on its line: `part def A; // note`
                    self.out.push(' ');
                    self.out.push_str(token.text());
                } else {
                    self.break_line(gap);
                    self.out.push_str(token.text());
                }
                self.line_empty = false;
                self.pending_newlines = self.pending_newlines.max(1);
                self.prev = Some((*token).clone());
                continue;
            }

            if kind == R_BRACE {
                self.depth = self.depth.saturating_sub(1);
                if !self.line_empty {
                    self.pending_newlines = self.pending_newlines.max(1);
                }
            }
            // A block comment spanning lines keeps a line of its own, so
            // that its interior has a column of its own to be brought to.
            if kind == COMMENT_BODY && token.text().contains('\n') {
                self.pending_newlines = self.pending_newlines.max(1);
            }
            if self.pending_newlines > 0 {
                self.break_line(gap);
            } else if !self.line_empty {
                let prev = self.prev.clone().expect("non-empty line has a token");
                if space_between(&prev, token) {
                    if let Some(rank) = joint_rank(&prev, token) {
                        self.joints.push(Joint {
                            at: self.out.len(),
                            rank,
                            kept: gap >= 1,
                        });
                    }
                    self.out.push(' ');
                }
            }
            if kind == COMMENT_BODY && token.text().contains('\n') {
                self.write_comment(token.text());
                self.line_breakable = false;
            } else {
                self.out.push_str(token.text());
            }
            self.line_empty = false;

            match kind {
                L_BRACE => {
                    // keep `{}` on one line by emitting the pair atomically
                    if visible.get(index + 1).map(|t| t.kind()) == Some(R_BRACE) {
                        self.out.push('}');
                        self.pending_newlines = 1;
                        self.prev = Some(visible[index + 1].clone());
                        skip_next = true;
                        continue;
                    }
                    self.depth += 1;
                    self.pending_newlines = 1;
                }
                R_BRACE => {
                    // `} ;` closes a body that a `;` still has to end, and
                    // only that keeps the brace from ending its line. The
                    // search skips notes, so it is done here rather than for
                    // every token: a run of n notes would otherwise cost n^2.
                    let next_kind = visible
                        .iter()
                        .skip(index + 1)
                        .find(|t| !is_note(t.kind()))
                        .map(|t| t.kind());
                    if next_kind != Some(SEMICOLON) {
                        self.pending_newlines = 1;
                    }
                }
                SEMICOLON | COMMENT_BODY => self.pending_newlines = 1,
                _ => {}
            }
            self.prev = Some((*token).clone());
        }

        self.lay_out_line();
        while self.out.ends_with(['\n', ' ', '\t']) {
            self.out.pop();
        }
        if !self.out.is_empty() {
            self.out.push('\n');
        }
        self.out
    }

    /// A block comment that spans lines, its interior brought under the
    /// column the `/*` now sits in.
    ///
    /// The interior is part of the same token as the `/*`, so moving the
    /// one used to leave the other standing in a column that meant
    /// something in the file it was written in and nothing in the file
    /// that came out. What the comment says is unchanged: a body is read
    /// with this margin taken off.
    fn write_comment(&mut self, text: &str) {
        let indent = INDENT.repeat(self.depth);
        let mut lines = text.lines();
        self.out.push_str(lines.next().unwrap_or_default());
        let mut rest: Vec<&str> = lines.collect();
        // A line that only closes the comment is part of the drawing and
        // not of what is written inside it: left in, an author who put
        // `*/` hard against the left margin would have said that the
        // margin is nothing, and every line under it would keep the
        // indentation it had.
        let closes = rest.last().is_some_and(|line| line.trim() == "*/");
        if closes {
            rest.pop();
        }
        // The `*` down the side is a margin and is redrawn against the
        // new column; anything else is prose, whose own indentation says
        // something, so only the margin it shares is replaced.
        let said: Vec<&str> = rest
            .iter()
            .copied()
            .filter(|line| !line.trim().is_empty())
            .collect();
        let starred =
            !said.is_empty() && said.iter().all(|line| line.trim_start().starts_with('*'));
        let margin = if starred {
            String::new()
        } else {
            shared_indent(&said)
        };
        for line in rest {
            self.out.push('\n');
            if line.trim().is_empty() {
                continue; // a blank line stays blank rather than padded
            }
            self.out.push_str(&indent);
            if starred {
                // one space, so the `*` stands under the one in `/*`
                self.out.push(' ');
                self.out.push_str(line.trim_start());
            } else {
                // every line written here shares the margin, by the way
                // the margin was arrived at
                self.out.push_str(&line[margin.len()..]);
            }
        }
        if closes {
            self.out.push('\n');
            self.out.push_str(&indent);
            // under the `*` it has been standing under all the way down
            self.out.push_str(if starred { " */" } else { "*/" });
        }
    }

    /// Emit the pending newline(s) — preserving at most one original blank
    /// line — and the indentation for the new line.
    fn break_line(&mut self, original_gap: usize) {
        if self.prev.is_none() {
            self.pending_newlines = 0;
            return; // start of file
        }
        self.lay_out_line();
        let newlines = if original_gap >= 2 {
            2
        } else {
            self.pending_newlines.max(1)
        };
        for _ in 0..newlines {
            self.out.push('\n');
        }
        for _ in 0..self.depth {
            self.out.push_str(INDENT);
        }
        self.pending_newlines = 0;
        self.line_empty = true;
        self.line_start = self.out.len();
        self.line_indent = self.depth * INDENT.len();
        self.joints.clear();
        self.line_breakable = true;
    }

    /// Break the line just written where it is too wide to read, and
    /// where its author broke it.
    ///
    /// Nothing decides this while the line is being written: whether it
    /// is too long is not known until it ends, and which joint should
    /// give way depends on what the rest of the line turned out to be.
    /// So the line is written flat and opened up here, at the spaces
    /// that were noted as it went by.
    fn lay_out_line(&mut self) {
        if !self.line_breakable || self.joints.is_empty() {
            return;
        }
        // a width of nothing is no width to keep to, so only the breaks
        // the author wrote are kept
        if self.layout.width == 0 {
            let kept: Vec<usize> = self
                .joints
                .iter()
                .filter(|joint| joint.kept)
                .map(|joint| joint.at)
                .collect();
            self.open_at(kept);
            return;
        }
        let mut chosen: Vec<usize> = self
            .joints
            .iter()
            .filter(|joint| joint.kept)
            .map(|joint| joint.at)
            .collect();
        // Then as many more as the width asks for: the widest stretch
        // that is still too long gives way at its readiest joint, and
        // the two halves are measured in their turn.
        while let Some((from, to)) = self.widest_over(&chosen) {
            let within = || {
                self.joints
                    .iter()
                    .filter(|joint| joint.at > from && joint.at < to)
                    .filter(|joint| !chosen.contains(&joint.at))
            };
            let Some(readiest) = within().map(|joint| joint.rank).min() else {
                break; // nothing left to give: a long name is a long line
            };
            // every joint of that kind, not just the one that would do:
            // an `else` arm on a line of its own and the next one
            // trailing the line above reads as two different things
            let giving: Vec<usize> = within()
                .filter(|joint| joint.rank == readiest)
                .map(|joint| joint.at)
                .collect();
            chosen.extend(giving);
        }
        self.open_at(chosen);
    }

    /// Break the line at each of `at`, which are offsets of the spaces
    /// that give way. Spliced from the end, so that each one leaves the
    /// offsets before it where they were.
    fn open_at(&mut self, mut at: Vec<usize>) {
        at.sort_unstable();
        let indent = " ".repeat(self.line_indent + INDENT.len());
        for at in at.into_iter().rev() {
            self.out.replace_range(at..at + 1, &format!("\n{indent}"));
        }
    }

    /// The stretch of the line between two breaks that is over the
    /// width, widest first, or nothing when they all fit.
    fn widest_over(&self, chosen: &[usize]) -> Option<(usize, usize)> {
        let mut edges: Vec<usize> = chosen.to_vec();
        edges.sort_unstable();
        let mut stretches: Vec<(usize, usize)> = Vec::new();
        let mut from = self.line_start;
        for &at in &edges {
            stretches.push((from, at));
            from = at + 1;
        }
        stretches.push((from, self.out.len()));
        stretches
            .into_iter()
            .enumerate()
            .map(|(at, (from, to))| {
                // the first stretch carries the line's own indent; every
                // one after it carries that and a step more
                let indent = self.line_indent + usize::from(at > 0) * INDENT.len();
                (indent + columns(&self.out[from..to]), (from, to))
            })
            .filter(|(width, _)| *width > self.layout.width)
            .max_by_key(|(width, _)| *width)
            .map(|(_, stretch)| stretch)
    }

    /// Newlines in the original text between the previous visible token and
    /// `next` (whitespace trivia only).
    fn original_gap_lines(&self, next: &SyntaxToken) -> usize {
        let Some(prev) = &self.prev else { return 0 };
        let mut lines = 0;
        let mut cursor = prev.next_token();
        while let Some(t) = cursor {
            if t.text_range() == next.text_range() {
                break;
            }
            if t.kind() == WHITESPACE {
                lines += t.text().matches('\n').count();
            }
            cursor = t.next_token();
        }
        lines
    }
}

fn is_note(kind: SyntaxKind) -> bool {
    matches!(kind, LINE_NOTE | BLOCK_NOTE)
}

/// Should a single space separate `prev` and `next`?
fn space_between(prev: &SyntaxToken, next: &SyntaxToken) -> bool {
    let p = prev.kind();
    let n = next.kind();

    // never before closers / separators
    if matches!(n, SEMICOLON | COMMA | R_PAREN | R_BRACKET) {
        return false;
    }
    // never after openers and prefix markers -- `~P` conjugates the type
    // it stands in front of, where `feature g ~ B::f` writes the same
    // relationship as a clause, spaced like the `conjugates` it stands for
    if matches!(p, L_PAREN | L_BRACKET | HASH | AT | AT_AT | DOLLAR)
        || p == TILDE && prev.parent().is_none_or(|parent| parent.kind() != RELATION)
    {
        return false;
    }
    // tight path/scope operators
    if matches!(p, COLON_COLON | DOT | DOT_QUESTION | DOT_DOT)
        || matches!(n, COLON_COLON | DOT | DOT_QUESTION | DOT_DOT)
    {
        return false;
    }
    // `<shortName>` is tight inside the brackets; `a < b` is not
    if (p == LT && in_short_name(prev)) || (n == GT && in_short_name(next)) {
        return false;
    }
    // unary sign binds to its operand
    if matches!(p, MINUS | PLUS)
        && prev
            .parent()
            .is_some_and(|parent| parent.kind() == UNARY_EXPR)
    {
        return false;
    }
    // calls and multiplicities attach to names: `f(x)`, `Wheel[4]`
    if n == L_PAREN {
        return !matches!(p, IDENT | UNRESTRICTED_NAME | R_PAREN | R_BRACKET);
    }
    if n == L_BRACKET {
        return !matches!(p, IDENT | UNRESTRICTED_NAME | R_PAREN);
    }
    true
}

fn in_short_name(token: &SyntaxToken) -> bool {
    matches!(token.kind(), LT | GT) && token.parent().is_some_and(|p| p.kind() == SHORT_NAME)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A caller that has a tree in hand formats from it, and gets what
    /// formatting the text would have given. The command line goes this
    /// way -- it parses to find out whether the file is worth rewriting
    /// at all -- and says nothing about the width, which is the default.
    #[test]
    fn a_tree_in_hand_need_not_be_parsed_again() {
        let text = "package P{part def A;}";
        let parse = crate::parse_dialect(text, Dialect::SysML);
        assert_eq!(format_parsed(&parse), fmt(text));
    }

    fn fmt(text: &str) -> String {
        format(text, Dialect::SysML)
    }

    #[test]
    fn normalizes_spacing_and_indentation() {
        let input =
            "package   P{part def Vehicle{attribute mass:Real=1200.0;part wheels:Wheel[4];}}";
        let expected = "package P {\n    part def Vehicle {\n        attribute mass : Real = 1200.0;\n        part wheels : Wheel[4];\n    }\n}\n";
        assert_eq!(fmt(input), expected);
    }

    #[test]
    fn preserves_single_blank_lines() {
        let input = "package P {\n    part def A;\n\n\n\n    part def B;\n}\n";
        let expected = "package P {\n    part def A;\n\n    part def B;\n}\n";
        assert_eq!(fmt(input), expected);
    }

    #[test]
    fn keeps_trailing_and_own_line_notes() {
        let input =
            "package P {\n    part def A; // trailing\n    // own line\n    part def B;\n}\n";
        let expected =
            "package P {\n    part def A; // trailing\n    // own line\n    part def B;\n}\n";
        assert_eq!(fmt(input), expected);
    }

    #[test]
    fn short_names_and_operators() {
        let input = "attribute def <kg> Kilogram;\nattribute ok = a<b and x>=y;";
        let expected = "attribute def <kg> Kilogram;\nattribute ok = a < b and x >= y;\n";
        assert_eq!(fmt(input), expected);
    }

    #[test]
    fn empty_bodies_stay_on_one_line() {
        assert_eq!(fmt("part def A {}"), "part def A {}\n");
        assert_eq!(fmt("part def A {  }"), "part def A {}\n");
    }

    #[test]
    fn a_doc_spanning_lines_keeps_its_own_line() {
        let input = "package P {\n    doc\n    /*\n     * about P\n     */\n}\n";
        assert_eq!(fmt(input), input);
    }

    /// The interior is part of the same token as the `/*`, so moving one
    /// without the other used to leave the body standing in a column
    /// that meant nothing -- which is what a reader saw whenever their
    /// editor formatted a file whose indentation was not already right.
    #[test]
    fn a_doc_that_moves_takes_its_body_with_it() {
        let input = "package P {\npart def V {\ndoc\n/*\n * first\n *\n * second\n */\nattribute mass;\n}\n}\n";
        let expected = "package P {\n    part def V {\n        doc\n        /*\n         * first\n         *\n         * second\n         */\n        attribute mass;\n    }\n}\n";
        assert_eq!(fmt(input), expected);
        // and again, which is the same file
        assert_eq!(fmt(expected), expected);
        // what it says is what it said, which is what lets it be moved
        assert_eq!(
            crate::comment_text("/*\n * first\n *\n * second\n */"),
            crate::comment_text("/*\n         * first\n         *\n         * second\n         */")
        );
    }

    /// A body drawn with no `*` down it keeps the shape it was written
    /// in: what is indented inside it stays indented inside it.
    #[test]
    fn a_body_with_no_margin_keeps_its_own_shape() {
        let input = "package P {\npart def V {\ndoc\n/*\n  first\n    indented\n*/\n}\n}\n";
        let expected =
            "package P {\n    part def V {\n        doc\n        /*\n        first\n          indented\n        */\n    }\n}\n";
        assert_eq!(fmt(input), expected);
        assert_eq!(fmt(expected), expected);
    }

    #[test]
    fn docs_end_their_line() {
        let input = "package P { doc /* about P */ part def A; }";
        let expected = "package P {\n    doc /* about P */\n    part def A;\n}\n";
        assert_eq!(fmt(input), expected);
    }

    #[test]
    fn kerml_dialect_empty_input_and_unterminated_comments() {
        assert_eq!(
            crate::fmt::format_file("m.kerml", "classifier   A;"),
            "classifier A;\n"
        );
        assert_eq!(fmt(""), "");
        // an unterminated comment body ends with whitespace that must be
        // trimmed from the output
        let out = fmt("doc /* open  ");
        assert!(out.ends_with("open\n"), "{out:?}");
    }

    /// `~` is a word where it stands for `conjugates` and a mark where
    /// it stands in front of a type.
    #[test]
    fn a_conjugation_clause_is_spaced_like_the_word_it_stands_for() {
        assert_eq!(
            crate::fmt::format_file("m.kerml", "feature g ~B::f;"),
            "feature g ~ B::f;\n"
        );
        assert_eq!(fmt("port p : ~ P;"), "port p : ~P;\n");
    }

    #[test]
    fn a_crlf_file_comes_out_with_one_kind_of_line_ending() {
        let input = "package P {\r\n    part def A; // note\r\n    part def B;\r\n}\r\n";
        let out = fmt(input);
        assert!(!out.contains('\r'), "{out:?}");
        assert_eq!(
            out,
            "package P {\n    part def A; // note\n    part def B;\n}\n"
        );
        assert_eq!(fmt(&out), out);
    }

    #[test]
    fn a_byte_order_mark_survives_formatting() {
        assert_eq!(fmt("\u{feff}part   def A;"), "\u{feff}part def A;\n");
        // and only the one at the front: elsewhere it is spacing
        assert_eq!(fmt("part\u{feff}def A;"), "part def A;\n");
    }

    /// A run of notes used to cost the formatter a scan each, so a file
    /// that is mostly notes took time in the square of its length.
    #[test]
    fn a_file_of_notes_formats_in_one_pass() {
        let input = "part def A {\n".to_string() + &"    // note\n".repeat(20_000) + "}\n";
        let started = std::time::Instant::now();
        let out = fmt(&input);
        assert_eq!(out, input);
        assert!(started.elapsed() < std::time::Duration::from_secs(5));
    }

    /// A formula too wide to read is opened at its outermost joints,
    /// and at every one of them, so that what is on each line is one
    /// arm of the same choice.
    #[test]
    fn a_line_too_wide_gives_way_at_its_readiest_joints() {
        let input = "calc def D { in c : Integer; return u : String = if c == 1 ? \"first say this\" else if c == 2 ? \"or else say this\" else if c == 3 ? \"or this instead\" else \"\"; }";
        let out = fmt(input);
        let arms: Vec<&str> = out.lines().filter(|line| line.contains("else")).collect();
        assert_eq!(arms.len(), 3, "{out}");
        for arm in &arms {
            assert!(arm.starts_with("        else"), "{out}");
        }
        assert!(
            out.lines().all(|line| super::columns(line) <= WIDTH),
            "{out}"
        );
        assert_eq!(fmt(&out), out);
    }

    /// Width is columns, not characters: a line of Japanese is twice as
    /// wide as it is long, and a formatter that counted characters would
    /// leave it running off the page.
    #[test]
    fn a_wide_script_is_measured_in_what_it_takes_up() {
        assert_eq!(columns("ab"), 2);
        assert_eq!(columns("\u{6ce8}\u{610f}"), 4);
        let input = "part def P { attribute a = \"\u{6ce8}\u{610f}\u{3057}\u{3066}\u{304f}\u{3060}\u{3055}\u{3044}\" + \"\u{3082}\u{3046}\u{4e00}\u{5ea6}\u{8a00}\u{3044}\u{307e}\u{3059}\" + \"\u{305d}\u{308c}\u{304b}\u{3089}\u{3053}\u{3046}\u{3057}\u{307e}\u{3059}\" + \"\u{6700}\u{5f8c}\u{306b}\u{3053}\u{3046}\u{3057}\u{307e}\u{3059}\"; }";
        let out = fmt(input);
        assert!(out.lines().count() > 3, "{out}");
        assert!(
            out.lines().all(|line| super::columns(line) <= WIDTH),
            "{out}"
        );
    }

    /// Where the author broke the line is where it stays, fitting or
    /// not: how a formula is split says how it is meant to be read.
    #[test]
    fn a_break_the_author_wrote_is_kept() {
        let input = "part def P {\n    attribute a =\n        b + c;\n}\n";
        assert_eq!(fmt(input), input);
        // and one written flat that fits is left flat
        assert_eq!(
            fmt("part def P { attribute a = b + c; }"),
            "part def P {\n    attribute a = b + c;\n}\n"
        );
    }

    /// The width is the caller's to set: a narrower one gives way at
    /// joints a wider one leaves alone, and nothing is what nothing is
    /// measured against.
    #[test]
    fn the_width_is_the_callers_to_set() {
        let flat = "part def P { attribute a = b and c and d; }";
        let wide = |text: &str, width: usize| format_with(text, Dialect::SysML, Layout { width });
        // a hundred columns holds it; twenty does not
        assert_eq!(
            wide(flat, 100),
            "part def P {\n    attribute a = b and c and d;\n}\n"
        );
        let narrow = wide(flat, 20);
        assert_eq!(
            narrow.lines().filter(|line| line.contains("and")).count(),
            2,
            "{narrow}"
        );
        assert_eq!(wide(&narrow, 20), narrow);

        // a width of nothing leaves the line as long as it comes
        let long = "part def P { attribute a = if x == 1 ? \"one\" else if x == 2 ? \"two\" else if x == 3 ? \"three\" else \"nothing at all\"; }";
        let unwrapped = wide(long, 0);
        assert_eq!(unwrapped.lines().count(), 3, "{unwrapped}");
        assert!(
            super::columns(unwrapped.lines().nth(1).unwrap()) > WIDTH,
            "{unwrapped}"
        );
        // and still keeps the breaks the author wrote
        let broken = "part def P {\n    attribute a =\n        b + c;\n}\n";
        assert_eq!(wide(broken, 0), broken);
    }

    #[test]
    fn idempotent() {
        let input = "package P { /* doc-ish */ part x : X = f(1, 2) + -3; }";
        let once = fmt(input);
        assert_eq!(fmt(&once), once);
    }

    #[test]
    fn reparse_equivalence() {
        let input = "package P{part def V{attribute m:Real;}}";
        let formatted = fmt(input);
        let a = crate::parse(input);
        let b = crate::parse(&formatted);
        assert!(b.ok());
        let toks = |p: &crate::Parse| {
            p.syntax()
                .descendants_with_tokens()
                .filter_map(|e| e.into_token())
                .filter(|t| !t.kind().is_trivia())
                .map(|t| (t.kind(), t.text().to_string()))
                .collect::<Vec<_>>()
        };
        assert_eq!(toks(&a), toks(&b));
    }
}
