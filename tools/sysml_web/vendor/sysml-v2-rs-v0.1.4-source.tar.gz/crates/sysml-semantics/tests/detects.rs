//! Models that are wrong, and the constraints that say so.
//!
//! The official corpus is the ground truth for the other direction: every
//! file the OMG publishes is well-formed, so a constraint that fires on
//! one is this checker being wrong. That proves the checker does not cry
//! wolf; it proves nothing about whether it barks -- a constraint that can
//! never fire passes the corpus perfectly.
//!
//! So each model below is meant to be rejected, and the test is which
//! constraints notice. Every one was checked against the specification
//! first: `verify` belongs inside an `objective`, as
//! `VerificationTest.sysml` writes it, and an `enum def` is a variation,
//! so what it owns must be variants.
//!
//! Breaking the corpus, next door, reaches far more of them than writing
//! models by hand -- but not all. A constraint the corpus asks of three
//! elements has nothing much to break: of the hundred and eight that no
//! break had reached, nine were answered of fewer than ten elements. Six
//! of the models here came of aiming at those.
//!
//! A seventh came of asking why an aimed model did not work.
//! `validateSubjectMembershipOwningType` was answered of eighteen subjects
//! and could not have been false of any: it asks whether the owning type
//! is one of four and writes the second as a metaclass that does not
//! exist. Read as the constraint's own words say, a subject under an
//! action definition is reported.
//!
//! Skipped when the submodule is not checked out: without the library the
//! constraints report what is missing rather than what is wrong.

use std::collections::BTreeSet;

use sysml_corpus::{library, vendor};
use sysml_semantics::Workspace;

/// One wrong model, and every constraint that is expected to fire on it.
/// The set is exact in both directions: a rule that stops noticing fails
/// here, and so does one that starts complaining about something else.
const REJECTED: &[(&str, &str, &[&str])] = &[
    (
        "an objective belongs to a case",
        "package P {\n\tpart def E {\n\t\tobjective o;\n\t}\n}\n",
        &["validateObjectiveMembershipOwningType"],
    ),
    (
        "and so does a subject",
        "package P {\n\tpart def E {\n\t\tsubject s;\n\t}\n}\n",
        &[
            "validateParameterMembershipOwningType",
            "validateSubjectMembershipOwningType",
        ],
    ),
    (
        "a requirement has one subject or none",
        "package P {\n\trequirement def R {\n\t\tsubject a;\n\t\tsubject b;\n\t}\n}\n",
        &["validateRequirementDefinitionOnlyOneSubject"],
    ),
    (
        "a calculation returns once",
        "package P {\n\tcalc def C {\n\t\treturn x;\n\t\treturn y;\n\t}\n}\n",
        &["validateFunctionResultParameterMembership"],
    ),
    (
        "a variant belongs to a variation",
        "package P {\n\tpart def Q;\n\tpart v : Q {\n\t\tvariant part w : Q;\n\t}\n}\n",
        &["validateVariantMembershipOwningNamespace"],
    ),
    (
        "an enumeration is a variation, so what it owns must be variants",
        "package P {\n\tenum def E {\n\t\tpart inside;\n\t}\n}\n",
        &["validateDefinitionVariationOwnedFeatureMembership"],
    ),
    (
        "an assumption belongs to a requirement",
        "package P {\n\tpart def E {\n\t\tassume constraint c;\n\t}\n}\n",
        &["validateRequirementConstraintMembershipOwningType"],
    ),
    (
        "and so does what it requires",
        "package P {\n\tpart def E {\n\t\trequire constraint c;\n\t}\n}\n",
        &["validateRequirementConstraintMembershipOwningType"],
    ),
    (
        "and the concern it frames",
        "package P {\n\tpart def E {\n\t\tframe concern c;\n\t}\n}\n",
        &["validateRequirementConstraintMembershipOwningType"],
    ),
    (
        "an actor belongs to a requirement or a case",
        "package P {\n\tpart def E {\n\t\tactor a;\n\t}\n}\n",
        &[
            "validateActorMembershipOwningType",
            "validateParameterMembershipOwningType",
        ],
    ),
    (
        "and so does a stakeholder",
        "package P {\n\tpart def E {\n\t\tstakeholder s;\n\t}\n}\n",
        &[
            "validateParameterMembershipOwningType",
            "validateStakeholderMembershipOwningType",
        ],
    ),
    (
        "only something that returns has a return parameter",
        "package P {\n\tpart def E {\n\t\treturn x;\n\t}\n}\n",
        &[
            "validateParameterMembershipOwningType",
            "validateReturnParameterMembershipOwningType",
        ],
    ),
    (
        "an expose belongs to a view",
        "package P {\n\tpart def Q;\n\texpose Q;\n}\n",
        &["validateExposeOwningNamespace"],
    ),
    (
        "a rendering belongs to a view",
        "package P {\n\tpart def Q;\n\tpart q : Q {\n\t\trender asTree;\n\t}\n}\n",
        &["validateViewRenderingMembershipOwningType"],
    ),
    (
        "a subject belongs to a requirement or a case, and this is an action",
        "package P {\n\tpart def Q;\n\taction def A {\n\t\tsubject s : Q;\n\t}\n}\n",
        &["validateSubjectMembershipOwningType"],
    ),
    (
        "a view renders one way",
        "package P {\n\trendering def R;\n\tview def V {\n\t\trender r1 : R;\n\t\trender r2 : R;\n\t}\n}\n",
        &["validateViewDefinitionOnlyOneViewRendering"],
    ),
    (
        "and so does a use of one",
        "package P {\n\trendering def R;\n\tview def V;\n\tview v : V {\n\t\trender r1 : R;\n\t\trender r2 : R;\n\t}\n}\n",
        &["validateViewUsageOnlyOneViewRendering"],
    ),
    (
        "a decision is reached one way",
        "package P {\n\taction def A {\n\t\taction a;\n\t\taction b;\n\t\tdecide d;\n\t\taction c;\n\
         \t\tfirst a then d;\n\t\tfirst b then d;\n\t\tfirst d then c;\n\t}\n}\n",
        &["validateDecisionNodeIncomingSuccessions"],
    ),
    (
        "an expose is protected, whatever it says",
        "package P {\n\tpart def Q;\n\tview def V;\n\tview v : V {\n\t\tpublic expose Q;\n\t}\n}\n",
        &["validateExposeVisibility"],
    ),
    (
        "what an `at` waits for is a time, not a part",
        "package P {\n\tpart def Q;\n\tpart q : Q;\n\taction def A {\n\t\taccept at q;\n\t}\n}\n",
        &["validateTriggerInvocationExpressionAtArgument"],
    ),
    (
        "and what a `when` watches is a change",
        "package P {\n\tpart def Q;\n\tpart q : Q;\n\taction def A {\n\t\taccept when q;\n\t}\n}\n",
        &["validateTriggerInvocationExpressionWhenArgument"],
    ),
    (
        "a verification verifies inside its objective, not beside it",
        "package P {\n\trequirement def R;\n\tverification def V {\n\t\tverify requirement R;\n\t}\n}\n",
        &[
            "validateRequirementConstraintMembershipOwningType",
            "validateRequirementVerificationMembershipOwningType",
        ],
    ),
];

#[test]
fn a_model_the_standard_rejects_is_reported_as_rejected() {
    let library = library();
    // The library is resolved once and every model is asked against it:
    // asking costs about a millisecond, and this is the second the whole
    // file spends.
    let mut ws = Workspace::new();
    ws.load_dir(&library).expect("the library loads");
    ws.resolve_all();

    for (says, source, expected) in REJECTED {
        let file = ws.add_file("wrong.sysml", source);
        ws.resolve_files(&[file]);
        let found = ws.findings(&[file]);
        assert!(found.syntax.is_empty(), "{says}: does not parse {found:?}");
        assert!(found.names.is_empty(), "{says}: does not resolve {found:?}");

        let fired: BTreeSet<&str> = ws
            .check_rules(&[file])
            .violations
            .iter()
            .map(|violation| violation.rule)
            .collect();
        let wanted: BTreeSet<&str> = expected.iter().copied().collect();
        assert_eq!(fired, wanted, "{says}");
    }
}

/// The same question asked of the corpus, by breaking it on purpose.
///
/// Writing a wrong model by hand reaches the constraints one at a time,
/// and only the ones whose shape is already understood. The corpus is 403
/// files of rich, correct SysML: change one thing in one of them and it is
/// still a model, still parses, still resolves -- and is now wrong in a
/// way somebody's editor could be wrong.
///
/// Four sweeps got here. Fifty keyword swaps over every file left 1674
/// models, tripped twenty-six constraints, and found a panic: `connector
/// ps : P ([0..*] myCart, ...)` counted the `*` of the bound as a step of
/// the name beside it. A second widened the swaps past the definition
/// keywords -- 4257 models, thirty-nine constraints. A third broke one
/// place at a time and took whole lines out and put them in twice: 12040
/// models, fourteen more. A fourth reordered neighbouring lines and broke
/// two places at once, and found nothing new. Only the first found a
/// panic.
///
/// What the fourth did find was elsewhere: breaking the standard library
/// rather than a model reaches four more, next door. Sixty-two of the
/// hundred and seventy answered constraints are demonstrated to fire.
///
/// Each row is one break, the file it is made in, and constraints that
/// must notice. Others may notice too -- one keyword can be wrong several
/// ways at once -- so the named ones must be among what fires rather than
/// all of it.
#[derive(Clone, Copy)]
enum Break {
    /// every occurrence of the first, written as the second
    Swap(&'static str, &'static str),
    /// only the occurrence at that index, counted from zero
    SwapNth(&'static str, &'static str, usize),
    /// one line taken out, counted from one
    Drop(usize),
    /// one line written twice
    Repeat(usize),
}

use Break::{Drop, Repeat, Swap, SwapNth};

const MUTATED: &[(&str, Break, &[&str])] = &[
    (
        "UseCaseTest.sysml",
        Swap("use case def ", "part def "),
        &["validateActorMembershipOwningType"],
    ),
    (
        "CauseAndEffectExample.sysml",
        Swap("end ", ""),
        &[
            "validateAssociationRelatedTypes",
            "validateConnectorRelatedFeatures",
        ],
    ),
    (
        "EnumerationTest.sysml",
        Swap("attribute def ", "part def "),
        &[
            "validateAttributeDefinitionFeatures",
            "validateDataTypeSpecialization",
        ],
    ),
    (
        "Vehicle Analysis Demo.sysml",
        Swap("attribute def ", "part def "),
        &["validateAttributeUsageFeatures"],
    ),
    (
        "Connectors.kerml",
        Swap("end ", ""),
        &["validateBindingConnectorIsBinary"],
    ),
    (
        "Model Library Example.sysml",
        Swap("connection def ", "part def "),
        &["validateClassSpecialization"],
    ),
    (
        "ConnectionTest.sysml",
        Swap("then ", "; //"),
        &["validateConnectorBinarySpecialization"],
    ),
    (
        "ControlNodeTest.sysml",
        Swap("action def ", "part def "),
        &["validateControlNodeOwningType"],
    ),
    (
        "Features.kerml",
        Swap("composite ", "portion "),
        &["validateFeaturePortionNotVariable"],
    ),
    (
        "Conditional Succession Example-2.sysml",
        Swap("then ", "; //"),
        &["validateIfActionUsageParameters"],
    ),
    (
        "RootPackageTest.sysml",
        Swap("private ", "public "),
        &["validateImportTopLevelVisibility"],
    ),
    (
        "Dynamics.sysml",
        Swap("calc def ", "part def "),
        &[
            "validateInvocationExpressionInstantiatedType",
            "validateParameterMembershipOwningType",
            "validateReturnParameterMembershipOwningType",
        ],
    ),
    (
        "Dynamics.sysml",
        Swap("\n\t\tin ", "\n\t\tout "),
        &["validateInvocationExpressionParameterRedefinition"],
    ),
    (
        "ActionTest.sysml",
        Swap("first ", ""),
        &["validateMergeNodeOutgoingSuccessions"],
    ),
    (
        "Vehicle Analysis Demo.sysml",
        Swap("analysis def ", "part def "),
        &["validateObjectiveMembershipOwningType"],
    ),
    (
        "A-3-8-ChangingFeatureValues.kerml",
        Swap("\n\t\tin ", "\n\t\tout "),
        &["validateRedefinitionDirectionConformance"],
    ),
    (
        "Vehicle Analysis Demo.sysml",
        Swap("requirement def ", "part def "),
        &["validateRequirementConstraintMembershipOwningType"],
    ),
    (
        "Turbojet Stage Analysis.sysml",
        Swap("calc def ", "part def "),
        &["validateResultExpressionMembershipOwningType"],
    ),
    (
        "ViewTest.sysml",
        Swap("concern def ", "part def "),
        &["validateStakeholderMembershipOwningType"],
    ),
    (
        "AssignmentTest.sysml",
        Swap("state def ", "part def "),
        &["validateStateSubactionMembershipOwningType"],
    ),
    (
        "VariabilityTest.sysml",
        Swap("variation ", ""),
        &["validateVariantMembershipOwningNamespace"],
    ),
    (
        "ViewTest.sysml",
        Swap("view def ", "part def "),
        &["validateViewRenderingMembershipOwningType"],
    ),
    (
        "CarWithShapeAndCSG.sysml",
        Swap("part def ", "action def "),
        &["validateBehaviorSpecialization"],
    ),
    (
        "A-3-7-DecisionsAndMerges.kerml",
        Swap("behavior ", "struct "),
        &["validateStructureSpecialization"],
    ),
    (
        "ProductSelection_N_ary.kerml",
        Swap("member ", ""),
        &["validateFeatureCrossFeatureSpecialization"],
    ),
    (
        "AnalysisIndividualExample.sysml",
        Swap(" = ", " := "),
        &["validateFeatureIsVariable"],
    ),
    (
        "AnalysisIndividualExample.sysml",
        Swap("part def ", "attribute def "),
        &["validateOccurrenceUsageIndividualUsage"],
    ),
    (
        "JohnIndividualExample.sysml",
        Swap("individual ", ""),
        &["validateOccurrenceUsagePortionKind"],
    ),
    (
        "StructuredControlTest.sysml",
        Swap("in ", "inout "),
        &["validateForLoopActionUsageParameters"],
    ),
    (
        "TradeStudyTest.sysml",
        Swap("in ", "inout "),
        &["validateParameterMembershipParameterDirection"],
    ),
    (
        "ControlNodeTest.sysml",
        Swap("join", "fork"),
        &["validateForkNodeIncomingSuccessions"],
    ),
    (
        "ActionTest.sysml",
        Swap("if ", "while "),
        &["validateWhileLoopActionUsage"],
    ),
    (
        // Both restrictions on `annotatedElement` become
        // `PartDefinition`, and every element the metadata is about is a
        // part usage. (Turning the typing into a subsetting instead --
        // `:> annotatedElement :> SysML::PartDefinition` -- breaks the
        // name rather than the model: what a feature subsets is a
        // feature, and a metadata definition is not one.)
        "Metadata Example-1.sysml",
        SwapNth("SysML::PartUsage", "SysML::PartDefinition", 0),
        &["validateMetadataFeatureAnnotatedElement"],
    ),
    (
        "Classifiers.kerml",
        Swap("specializes ", "conjugates "),
        &["validateSpecificationSpecificNotConjugated"],
    ),
    (
        "JohnIndividualExample.kerml",
        Swap("specializes ", "conjugates "),
        &["validateTypeAtMostOneConjugator"],
    ),
    (
        "ProductSelection_UnownedEnds.kerml",
        SwapNth("end ", "", 0),
        &["validateCrossSubsettingCrossingFeature"],
    ),
    (
        "FeatureChains.kerml",
        SwapNth("chains ", "subsets ", 1),
        &["validateFeatureChainingFeatureNotOne"],
    ),
    (
        "A-3-6-Sequences.kerml",
        Repeat(37),
        &["validateAssociationBinarySpecialization"],
    ),
    (
        "VerificationTest.sysml",
        Repeat(16),
        &["validateCaseDefinitionOnlyOneSubject"],
    ),
    (
        "10c-Fuel Economy Analysis.sysml",
        Drop(79),
        &["validateCaseDefinitionSubjectParameterPosition"],
    ),
    (
        "Trade Study Analysis Example.sysml",
        Repeat(25),
        &["validateCaseUsageOnlyOneObjective"],
    ),
    (
        "10c-Fuel Economy Analysis.sysml",
        Repeat(148),
        &["validateCaseUsageOnlyOneSubject"],
    ),
    (
        "10c-Fuel Economy Analysis.sysml",
        Drop(148),
        &["validateCaseUsageSubjectParameterPosition"],
    ),
    (
        "ExtendedOccurrences.kerml",
        Repeat(19),
        &["validateExpressionResultParameterMembership"],
    ),
    (
        "SysML v2 Spec Annex A SimpleVehicleModel.sysml",
        Drop(817),
        &["validateFlowPayloadFeature"],
    ),
    (
        "Fork Join Example.sysml",
        Repeat(22),
        &["validateJoinNodeOutgoingSuccessions"],
    ),
    (
        "ViewTest.sysml",
        Drop(10),
        &["validateRequirementDefinitionSubjectParameterPosition"],
    ),
    (
        "VehicleRequirementDerivation.sysml",
        Repeat(31),
        &["validateRequirementUsageOnlyOneSubject"],
    ),
    (
        "Viewpoint Example.sysml",
        Drop(22),
        &["validateRequirementUsageSubjectParameterPosition"],
    ),
];

impl Break {
    /// The model this break makes of that text, or nothing where the
    /// text does not have what it breaks -- which is a corpus that has
    /// moved under the test, and is reported as such.
    fn made_of(self, text: &str) -> Option<String> {
        match self {
            Swap(from, to) => text.contains(from).then(|| text.replace(from, to)),
            SwapNth(from, to, nth) => {
                let mut at = 0;
                for _ in 0..nth {
                    at += text[at..].find(from)? + from.len();
                }
                let found = at + text[at..].find(from)?;
                Some(format!(
                    "{}{to}{}",
                    &text[..found],
                    &text[found + from.len()..]
                ))
            }
            Drop(line) => {
                let mut lines: Vec<&str> = text.lines().collect();
                (line <= lines.len()).then(|| {
                    lines.remove(line - 1);
                    lines.join("\n")
                })
            }
            Repeat(line) => {
                let mut lines: Vec<&str> = text.lines().collect();
                (line <= lines.len()).then(|| {
                    lines.insert(line - 1, lines[line - 1]);
                    lines.join("\n")
                })
            }
        }
    }
}

#[test]
fn a_corpus_file_broken_on_purpose_is_reported_as_broken() {
    // the library is `sysml-stdlib`'s and the examples are the
    // release's, so each is asked for where it lives
    let library = library();
    let Some(root) = vendor() else { return };
    let mut corpus = sysml_semantics::model_files(&root.join("sysml/src"));
    corpus.extend(sysml_semantics::model_files(&root.join("kerml/src")));

    let mut base = Workspace::new();
    base.load_dir(&library).expect("the library loads");
    base.resolve_all();
    let named = |kerml: bool| {
        if kerml {
            "mutated.kerml"
        } else {
            "mutated.sysml"
        }
    };

    for (name, broken, expected) in MUTATED {
        let path = corpus
            .iter()
            .find(|it| it.file_name().is_some_and(|it| it == *name))
            .unwrap_or_else(|| panic!("{name} is in the corpus"));
        let text = std::fs::read_to_string(path).expect("the corpus reads");
        let mutated = broken
            .made_of(&text)
            .unwrap_or_else(|| panic!("{name} no longer has what this breaks"));

        // one break at a time, each against a library that was resolved
        // once: cloning it costs a tenth of what loading it does
        let mut ws = base.clone();
        let kerml = path.extension().is_some_and(|it| it == "kerml");
        let file = ws.add_file(named(kerml), &mutated);
        ws.resolve_files(&[file]);
        let found = ws.findings(&[file]);
        assert!(found.syntax.is_empty(), "{name}: does not parse");
        // A corpus file may be one of several a model is spread over,
        // and the names its neighbours declare are not here -- `import
        // Atoms::*;` names a package another file in the same directory
        // declares. So what counts is that breaking the file leaves
        // nothing unresolved that the file did not already leave
        // unresolved standing on its own, which is only worth the
        // second resolve when there is something to explain.
        if !found.names.is_empty() {
            let mut whole = base.clone();
            let unbroken = whole.add_file(named(kerml), &text);
            whole.resolve_files(&[unbroken]);
            let already: BTreeSet<String> = whole
                .findings(&[unbroken])
                .names
                .into_iter()
                .map(|it| it.what)
                .collect();
            for missing in &found.names {
                assert!(
                    already.contains(&missing.what),
                    "{name}: does not resolve {missing:?}"
                );
            }
        }

        let fired: BTreeSet<&str> = ws
            .check_rules(&[file])
            .violations
            .iter()
            .map(|violation| violation.rule)
            .collect();
        for rule in *expected {
            assert!(fired.contains(rule), "{name}: {fired:?}");
        }
    }
}

/// And the same of the standard library, which is the only way to reach
/// some of them.
///
/// `validatePartUsagePartDefinition` asks that at least one of a part's
/// definitions be a `PartDefinition`, and no model of its own can fail it:
/// `deriveFeatureType` says the types of a feature are those of its
/// typings *and of its subsettings*, so the implicit `Parts::parts` always
/// brings `Parts::Part` in. Make `Parts::Part` an item definition and the
/// constraint fires at once.
///
/// A break here means loading the library again with one file changed, so
/// these cost about a second each. There are four.
const LIBRARY_BROKEN: &[(&str, Break, &[&str])] = &[
    (
        "Parts.sysml",
        Swap("part def ", "item def "),
        &["validatePartUsagePartDefinition"],
    ),
    (
        "Occurrences.kerml",
        Repeat(941),
        &["validateFeatureCrossFeatureType"],
    ),
    (
        "CollectionFunctions.kerml",
        Repeat(66),
        &["validateMultiplicityRangeBounds"],
    ),
    (
        "FeatureReferencingPerformances.kerml",
        Swap("nonunique ", ""),
        &["validateSubsettingUniquenessConformance"],
    ),
];

#[test]
fn a_library_broken_on_purpose_is_reported_as_broken() {
    let library = library();
    let files = sysml_semantics::model_files(&library);

    for (name, broken, expected) in LIBRARY_BROKEN {
        let target = files
            .iter()
            .find(|it| it.file_name().is_some_and(|it| it == *name))
            .unwrap_or_else(|| panic!("{name} is in the library"));
        let mutated = broken
            .made_of(&std::fs::read_to_string(target).expect("the library reads"))
            .unwrap_or_else(|| panic!("{name} no longer has what this breaks"));

        // the whole library, with that one file saying something else
        let mut ws = Workspace::new();
        let mut which = 0;
        for path in &files {
            let text = match path == target {
                true => mutated.clone(),
                false => std::fs::read_to_string(path).expect("the library reads"),
            };
            let file = ws.add_file(path.to_string_lossy(), &text);
            if path == target {
                which = file;
            }
        }
        ws.resolve_all();
        let found = ws.findings(&[which]);
        assert!(found.syntax.is_empty(), "{name}: does not parse");
        assert!(found.names.is_empty(), "{name}: does not resolve {found:?}");

        let fired: BTreeSet<&str> = ws
            .check_rules(&[which])
            .violations
            .iter()
            .map(|violation| violation.rule)
            .collect();
        for rule in *expected {
            assert!(fired.contains(rule), "{name}: {fired:?}");
        }
    }
}
