//! Structural checks of a drawing against the model it came from, run over
//! the vendored SysML-v2-Release corpus.
//!
//! The other corpus tests ask whether the model is right. These ask whether
//! the picture is faithful to it: that every box stands for an element in
//! scope, that no element is drawn twice or lost, that every line ends on a
//! box, and that the specializations the model holds are exactly the ones
//! drawn.
//!
//! Skipped when the submodule is not checked out.

use std::collections::HashSet;

use sysml_corpus::{kerml_examples, sysml_examples};
use sysml_diagram::{definition_diagram, interconnection_diagram, Diagram, Relation, Shape};
use sysml_model::{ElementId, ElementKind, Model, Value};
use sysml_semantics::Workspace;

fn loaded(path: &std::path::Path) -> Workspace {
    let mut ws = Workspace::new();
    ws.add_file(
        path.to_string_lossy(),
        &std::fs::read_to_string(path).unwrap(),
    );
    ws.resolve_all();
    ws
}

/// Properties every drawing must have, whatever it is a drawing of.
fn check_shape(diagram: &Diagram, model: &Model, where_: &str) {
    let mut drawn = HashSet::new();
    for node in &diagram.nodes {
        assert!(
            drawn.insert(node.id),
            "{where_}: {:?} is drawn twice",
            node.id
        );
        match node.shape {
            // a box says what it stands for, and says the same thing
            // the model does: the name first, then the type it was
            // declared with and how many of it there are, if either
            Shape::Box => {
                let name = model.effective_name(node.id).unwrap_or_default();
                // `if c { ... }` is a node whether or not it was given a
                // name, and the keyword above it says what it is; every
                // other box has to name what it stands for
                let may_be_nameless = matches!(
                    model.kind(node.id),
                    ElementKind::IfActionUsage
                        | ElementKind::WhileLoopActionUsage
                        | ElementKind::ForLoopActionUsage
                );
                assert!(
                    !node.name.is_empty() || may_be_nameless,
                    "{where_}: a box with no name"
                );
                let said = node.name.strip_prefix(name).is_some_and(|rest| {
                    rest.is_empty() || rest.starts_with(" :") || rest.starts_with('[')
                });
                assert!(
                    said,
                    "{where_}: box `{}` does not name {:?}",
                    node.name, node.id
                );
            }
            // only the start marker is allowed to carry no label, and only
            // a succession can put one there
            Shape::Initial => {
                assert!(node.name.is_empty(), "{where_}: a marker with a name");
                assert_eq!(
                    model.kind(node.id),
                    ElementKind::SuccessionAsUsage,
                    "{where_}: a start marker that is not a succession"
                );
            }
            // the dot three or more ends meet at, named -- when it is
            // named at all -- by the connection itself
            Shape::ConnectionDot => {
                let name = model.effective_name(node.id).unwrap_or_default();
                assert_eq!(
                    node.name, name,
                    "{where_}: a connection dot that is not named by its connection"
                );
            }
            // a note carries what a comment says or what a metadata
            // usage was declared as, and nothing else has one
            Shape::Note => {
                assert!(
                    matches!(
                        model.kind(node.id),
                        ElementKind::Comment | ElementKind::MetadataUsage
                    ),
                    "{where_}: a {:?} drawn as a note",
                    model.kind(node.id)
                );
                assert!(!node.name.is_empty(), "{where_}: a note saying nothing");
            }
            // a control node is drawn as its glyph rather than a box, and
            // only a control node is: the shape has to say what the model
            // says the element is
            Shape::Bar | Shape::Diamond | Shape::Cross => {
                let kind = model.kind(node.id);
                let expected = match node.shape {
                    Shape::Bar => [ElementKind::ForkNode, ElementKind::JoinNode],
                    Shape::Diamond => [ElementKind::MergeNode, ElementKind::DecisionNode],
                    _ => [
                        ElementKind::TerminateActionUsage,
                        ElementKind::TerminateActionUsage,
                    ],
                };
                assert!(
                    expected.contains(&kind),
                    "{where_}: {:?} drawn as {:?}",
                    kind,
                    node.shape
                );
            }
        }
    }
    for edge in &diagram.edges {
        assert!(
            edge.from < diagram.nodes.len() && edge.to < diagram.nodes.len(),
            "{where_}: an edge leaves the diagram"
        );
        // A membership may land back on the box it left -- `part
        // subparts : Assembly;` inside `Assembly`, and `portion
        // focusedState : Camera` inside `Camera`, where a portion of a
        // thing really is typed by the thing -- and only a membership
        // may: a specialization of itself, a connection to itself or a
        // transition to itself is a model saying nothing.
        if edge.from == edge.to {
            assert!(
                matches!(
                    edge.relation,
                    Relation::Composition | Relation::Reference | Relation::Portion
                ),
                "{where_}: a {:?} onto itself",
                edge.relation
            );
        }
    }
}

/// The specializations the model holds between two drawn definitions --
/// worked out from the model rather than from the drawing code.
fn expected_specializations(model: &Model, drawn: &[ElementId]) -> Vec<(ElementId, ElementId)> {
    let mut out = Vec::new();
    for &subtype in drawn {
        for &relationship in model.owned(subtype) {
            if model.kind(relationship) != ElementKind::Subclassification {
                continue;
            }
            let Some(Value::Ref(supertype)) = model.maybe(relationship, "superclassifier") else {
                continue;
            };
            if drawn.contains(supertype) {
                out.push((subtype, *supertype));
            }
        }
    }
    out
}

#[test]
fn definition_diagrams_are_faithful_to_their_models() {
    let Some(root) = sysml_examples() else { return };
    let mut files = sysml_semantics::model_files(&root);
    if let Some(kerml) = kerml_examples() {
        files.extend(sysml_semantics::model_files(&kerml));
    }
    files.sort();
    assert!(files.len() > 100, "the corpus looks truncated");

    for path in &files {
        let ws = loaded(path);
        let model = ws.model();
        let diagram = definition_diagram(model, &[ws.root()]);
        let where_ = path.file_name().unwrap().to_string_lossy().to_string();
        check_shape(&diagram, model, &where_);

        // every box is a named classifier of this file, and nothing else
        // is -- a note stands for the comment or metadata it holds, and a
        // dot for the n-ary dependency its links meet at
        let drawn: Vec<ElementId> = diagram
            .nodes
            .iter()
            .filter(|node| !matches!(node.shape, Shape::Note | Shape::ConnectionDot))
            .map(|node| node.id)
            .collect();
        for &id in &drawn {
            assert!(
                model.kind(id).is_a(ElementKind::Classifier),
                "{where_}: {:?} is not a classifier",
                id
            );
        }
        let definitions: Vec<ElementId> = model
            .descendants(ws.root())
            .into_iter()
            .filter(|&id| model.kind(id).is_a(ElementKind::Classifier) && model.name(id).is_some())
            .collect();
        assert_eq!(
            drawn, definitions,
            "{where_}: the boxes are not the model's"
        );

        // and the specializations drawn are exactly the ones it holds
        let expected = expected_specializations(model, &drawn);
        let actual: Vec<(ElementId, ElementId)> = diagram
            .edges
            .iter()
            .filter(|edge| edge.relation == Relation::Specialization)
            .map(|edge| (drawn[edge.from], drawn[edge.to]))
            .collect();
        assert_eq!(actual, expected, "{where_}: specializations do not match");
    }
}

/// Whether `sub` reaches `sup` through what the model reified, so that
/// an inherited member can be told from a stray one: the
/// specializations, and the type a usage was declared with, since
/// `part v : Vehicle` is assembled from whatever a `Vehicle` is.
fn specializes(model: &Model, sub: ElementId, sup: ElementId) -> bool {
    let mut queue = vec![sub];
    let mut visited = std::collections::HashSet::new();
    while let Some(current) = queue.pop() {
        if !visited.insert(current) {
            continue;
        }
        if current == sup {
            return true;
        }
        queue.extend(model.type_of(current));
        for &rel in model.owned(current) {
            if model.kind(rel) != sysml_model::ElementKind::Subclassification {
                continue;
            }
            if let Some(sysml_model::Value::Ref(target)) = model.maybe(rel, "superclassifier") {
                queue.push(*target);
            }
        }
    }
    false
}

#[test]
fn interconnection_diagrams_only_draw_what_is_in_scope() {
    let Some(root) = sysml_examples() else { return };
    let files = sysml_semantics::model_files(&root);

    let mut drawn_any = 0usize;
    for path in &files {
        let ws = loaded(path);
        let model = ws.model();
        let owners: Vec<ElementId> = ws
            .named_elements()
            .map(|(id, _)| id)
            .filter(|&id| !model.owned(id).is_empty())
            .collect();
        for owner in owners {
            let diagram = interconnection_diagram(model, owner);
            if diagram.nodes.is_empty() {
                continue;
            }
            drawn_any += 1;
            let where_ = format!(
                "{}::{}",
                path.file_name().unwrap().to_string_lossy(),
                model.name(owner).unwrap_or_default()
            );
            check_shape(&diagram, model, &where_);

            // an internal view shows what the element is assembled
            // from: what it holds, and what it inherits from what it
            // specializes -- and nothing from anywhere else. The
            // element itself stands for the boundary the rest is drawn
            // inside, where it is assembled from nothing and all there
            // is to show is what sits on that boundary.
            for node in &diagram.nodes {
                let holder = model.owner(node.id).expect("a drawn member has an owner");
                assert!(
                    node.id == owner || holder == owner || specializes(model, owner, holder),
                    "{where_}: `{}` is neither its own nor inherited",
                    node.name
                );
            }
        }
    }
    assert!(drawn_any > 50, "hardly anything was drawn: {drawn_any}");
}
